<?
$MESS ['START_FROM_NAME'] = "Ordinal of item from which to build the chain";
$MESS ['BREADCRUMB_PATH_NAME'] = "Path for which the navigation chain is to be built (by default, the current site)";
$MESS ['BREADCRUMB_SITE_ID'] = "Site (used in multi-site version, if sites have different DOCUMENT_ROOT)";
?>