<?
$MESS ['MAIN_BREADCRUMB_NAME'] = "Навигационная цепочка";
$MESS ['MAIN_BREADCRUMB_DESC'] = "Выводит навигационную цепочку (\"хлебные крошки\")";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Навигация";
?>