<?
$MESS ['CMDESKTOP_DESC_NAME'] = "Personal Dashboard";
$MESS ['CMDESKTOP_DESC_DESCRIPTION'] = "Easily configurable personal dashboard";
?>