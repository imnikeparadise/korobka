<?
$MESS ['CMDESKTOP_PARAMS_ID'] = "Personal Dashboard ID";
$MESS ['CMDESKTOP_PARAMS_CAN_EDIT'] = "Allow all authorized users to manage their own Personal Dashboard";
$MESS ['CMDESKTOP_PARAMS_COLUMNS'] = "Number of columns";
$MESS ['CMDESKTOP_PARAMS_COLUMN_WITH'] = "Column width (px or %)";
$MESS ['CMDESKTOP_PARAMS_GADGETS'] = "Available gadgets";
$MESS ['CMDESKTOP_PARAMS_GADGETS_ALL'] = "(all available)";
$MESS ['CMDESKTOP_PARAMS_GADGET_PAR'] = "Default user settings for the gadget";
$MESS ['CMDESKTOP_PARAMS_GADGET_SET'] = "Gadget settings";
$MESS ['CMDESKTOP_PARAMS_NAME_TEMPLATE'] = "Name Format";
$MESS ['CMDESKTOP_PARAMS_NAME_TEMPLATE_DEFAULT'] = "#NAME# #LAST_NAME#";
$MESS ['CMDESKTOP_PARAMS_SHOW_LOGIN'] = "Show Login Name if no required user name fields are available";
$MESS ['CMDESKTOP_PARAMS_PM_URL'] = "Personal Message Page";
$MESS ['CMDESKTOP_PARAMS_PATH_TO_CONPANY_DEPARTMENT'] = "Template of Department Page Path";
$MESS ['CMDESKTOP_PARAMS_PATH_TO_VIDEO_CALL'] = "Video Call Page";
$MESS ['CMDESKTOP_PARAMS_DATE_TIME_FORMAT'] = "Date And Time Format";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR'] = "Show Year of Birth";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_Y'] = "all";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_M'] = "only males";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_N'] = "nobody";
$MESS ['CMDESKTOP_PARAMS_DATE_FORMAT_NO_YEAR'] = "Date Format (without year)";
$MESS ['CMDESKTOP_PARAMS_DATE_FORMAT'] = "Date Format";
?>