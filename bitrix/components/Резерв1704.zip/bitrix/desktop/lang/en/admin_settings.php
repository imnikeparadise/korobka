<?
$MESS["CMDESKTOP_ADMIN_COLUMNS"] = "Columns";
$MESS["CMDESKTOP_ADMIN_COLUMN_WIDTH"] = "Column width (px or %) #";
$MESS["CMDESKTOP_ADMIN_SETTINGS_DIALOG_TITLE"] = "Desktop Settings";
$MESS["CMDESKTOP_ADMIN_DESKTOP_NAME"] = "Desktop name";
$MESS["CMDESKTOP_ADMIN_DESKTOP_DELETE_CONFIRM"] = "Are you sure you want to delete the desktop #NAME#?";
?>