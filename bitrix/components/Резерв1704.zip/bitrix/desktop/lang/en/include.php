<?
$MESS["CMDESKTOP_UP_TITLE_STD"] = "Gadget Name";
?>