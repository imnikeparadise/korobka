<?
$MESS ['CMDESKTOP_DESC_NAME'] = "Рабочий стол";
$MESS ['CMDESKTOP_DESC_DESCRIPTION'] = "Настраиваемое для каждого пользователя рабочее место";
?>