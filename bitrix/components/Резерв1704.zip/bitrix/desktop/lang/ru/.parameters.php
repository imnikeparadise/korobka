<?
$MESS ['CMDESKTOP_PARAMS_ID'] = "Идентификатор";
$MESS ['CMDESKTOP_PARAMS_CAN_EDIT'] = "Разрешить настраивать рабочий стол всем авторизованным пользователям";
$MESS ['CMDESKTOP_PARAMS_COLUMNS'] = "Количество столбцов";
$MESS ['CMDESKTOP_PARAMS_COLUMN_WITH'] = "Размер столбца (px или %)";
$MESS ['CMDESKTOP_PARAMS_GADGETS'] = "Доступные гаджеты";
$MESS ['CMDESKTOP_PARAMS_GADGETS_ALL'] = "(все имеющиеся)";
$MESS ['CMDESKTOP_PARAMS_GADGET_PAR'] = "Настройки по умолчанию параметров пользователя для гаджета";
$MESS ['CMDESKTOP_PARAMS_GADGET_SET'] = "Настройки гаджета";
$MESS ['CMDESKTOP_PARAMS_NAME_TEMPLATE'] = "Отображение имени";
$MESS ['CMDESKTOP_PARAMS_NAME_TEMPLATE_DEFAULT'] = "#LAST_NAME# #NAME#";
$MESS ['CMDESKTOP_PARAMS_SHOW_LOGIN'] = "Показывать логин, если не задано имя";
$MESS ['CMDESKTOP_PARAMS_PM_URL'] = "Страница отправки личного сообщения";
$MESS ['CMDESKTOP_PARAMS_PATH_TO_CONPANY_DEPARTMENT'] = "Шаблон пути к странице подразделения";
$MESS ['CMDESKTOP_PARAMS_PATH_TO_VIDEO_CALL'] = "Страница видеозвонка";
$MESS ['CMDESKTOP_PARAMS_DATE_FORMAT_NO_YEAR'] = "Формат показа даты без года";
$MESS ['CMDESKTOP_PARAMS_DATE_FORMAT'] = "Формат показа даты";
$MESS ['CMDESKTOP_PARAMS_DATE_TIME_FORMAT'] = "Формат показа даты и времени";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR'] = "Показывать год рождения";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_Y'] = "всем";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_M'] = "только мужчинам";
$MESS ['CMDESKTOP_PARAMS_SHOW_YEAR_VALUE_N'] = "никому";
?>