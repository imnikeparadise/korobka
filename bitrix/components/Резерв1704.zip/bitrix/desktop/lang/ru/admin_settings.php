<?
$MESS["CMDESKTOP_ADMIN_COLUMNS"] = "Столбцов";
$MESS["CMDESKTOP_ADMIN_COLUMN_WIDTH"] = "Ширина столбца (px или %) #";
$MESS["CMDESKTOP_ADMIN_SETTINGS_DIALOG_TITLE"] = "Настройки рабочего стола";
$MESS["CMDESKTOP_ADMIN_DESKTOP_NAME"] = "Название рабочего стола";
$MESS["CMDESKTOP_ADMIN_DESKTOP_DELETE_CONFIRM"] = "Вы действительно хотите удалить рабочий стол #NAME#?";
?>