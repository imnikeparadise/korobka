<?
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_DIALOG_TITLE"] = "Управление рабочими столами";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_DIALOG_DESKTOP"] = "Рабочий стол ";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_NAME"] = "Название";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_DRAG"] = "Перетащить рабочий стол мышью";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_TOOLTIP_TEXT_EDIT"] = "Нажмите, чтобы редактировать название рабочего стола";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_TOOLTIP_UP"] = "Передвинуть рабочий стол выше";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_TOOLTIP_DOWN"] = "Передвинуть рабочий стол ниже";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_TOOLTIP_DELETE"] = "Удалить рабочий стол";
$MESS["CMDESKTOP_ADMIN_SETTINGS_ALL_JS_NONAME"] = "--- нет значения ---";
?>