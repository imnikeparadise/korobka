<?
$MESS ['NAME_TEMPLATE_TIP'] = "Допустимы шаблоны: #NAME# - имя, #LAST_NAME# - фамилия, #SECOND_NAME# - отчество, #NAME_SHORT#, #LAST_NAME_SHORT#, #SECOND_NAME_SHORT# - сокращенные до одной буквы имя, фамилия и отчество";
?>