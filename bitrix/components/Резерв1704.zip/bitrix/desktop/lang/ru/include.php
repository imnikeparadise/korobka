<?
$MESS["CMDESKTOP_UP_TITLE_STD"] = "Название гаджета";
?>