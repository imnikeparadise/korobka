<?
$MESS["CMDESKTOP_TDEF_ERR1"] = "Error while saving gadget position to server.";
$MESS["CMDESKTOP_TDEF_ERR2"] = "Error while adding gadget to server.";
$MESS["CMDESKTOP_TDEF_SETTINGS"] = "Settings";
$MESS["CMDESKTOP_TDEF_SETTINGS_DIALOG_TITLE"] = "Desktop Settings";
$MESS["CMDESKTOP_TDEF_SETTINGS_ALL_DIALOG_TITLE"] = "Manage Desktops";
$MESS["CMDESKTOP_TDEF_CONF"] = "Your desktop settings will be applied to all new or unconfigured desktops. Do you want to continue?";
$MESS["CMDESKTOP_TDEF_CLEAR_CONF"] = "Default parameters will be applied to your desktop. Continue?";
$MESS["CMDESKTOP_TDEF_ADD_BUTTON"] = "Add gadget";
$MESS["CMDESKTOP_TDEF_DESKTOPS"] = "Desktops: ";
$MESS["CMDESKTOP_TDEF_DESKTOP_SETTINGS_BUTTON"] = "Settings";
$MESS["CMDESKTOP_TDEF_DESKTOP_ADD"] = "Create new desktop";
$MESS["CMDESKTOP_TDEF_DESKTOP_SETTINGS"] = "Customize current desktop";
$MESS["CMDESKTOP_TDEF_DESKTOP_ALL_SETTINGS"] = "Customize all desktops";
$MESS["CMDESKTOP_TDEF_SET"] = "Save as default settings";
$MESS["CMDESKTOP_TDEF_CLEAR"] = "Reset current settings";
$MESS["CMDESKTOP_TDEF_CANCEL"] = "Cancel";
$MESS["CMDESKTOP_TDEF_DELETE"] = "Delete";
$MESS["CMDESKTOP_TDEF_HIDE"] = "Hide/Show";
$MESS["CMDESKTOP_TDEF_COLUMN_WIDTH"] = "Column width (px or %) #";
$MESS["CMDESKTOP_TDEF_GADGET_SETTINGS_DIALOG_TITLE"] = "Gadget Settings";
$MESS["CMDESKTOP_TDEF_ADMIN_TITLE"] = "Desktop: #TITLE#";
$MESS["CMDESKTOP_TDEF_ADMIN_TITLE_DEFAULT"] = "Desktop #NUM#";
$MESS["CMDESKTOP_TDEF_PUBLIC"] = "The \"admin\" template cannot be used in the public area.";
?>