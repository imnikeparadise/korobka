<?
$MESS["CMDESKTOP_TDEF_ERR1"] = "Ошибка сохранения позиции гаджета на сервере.";
$MESS["CMDESKTOP_TDEF_ERR2"] = "Ошибка добавления гаджета на сервере.";
$MESS["CMDESKTOP_TDEF_SETTINGS"] = "Настроить";
$MESS["CMDESKTOP_TDEF_SETTINGS_DIALOG_TITLE"] = "Настройки рабочего стола";
$MESS["CMDESKTOP_TDEF_SETTINGS_ALL_DIALOG_TITLE"] = "Управление рабочими столами";
$MESS["CMDESKTOP_TDEF_CONF"] = "Ваши настройки рабочего стола будут применяться по умолчанию ко всем новым, а также не настраивавшимся ранее рабочим столам. Продолжить?";
$MESS["CMDESKTOP_TDEF_CLEAR_CONF"] = "Для вашего рабочего стола будут применяться настройки по умолчанию. Продолжить?";
$MESS["CMDESKTOP_TDEF_ADD_BUTTON"] = "Добавить гаджет";
$MESS["CMDESKTOP_TDEF_DESKTOPS"] = "Рабочие столы: ";
$MESS["CMDESKTOP_TDEF_DESKTOP_SETTINGS_BUTTON"] = "Настройки";
$MESS["CMDESKTOP_TDEF_DESKTOP_ADD"] = "Создать новый рабочий стол";
$MESS["CMDESKTOP_TDEF_DESKTOP_SETTINGS"] = "Настроить текущий рабочий стол";
$MESS["CMDESKTOP_TDEF_DESKTOP_ALL_SETTINGS"] = "Настроить все рабочие столы";
$MESS["CMDESKTOP_TDEF_SET"] = "Сохранить как настройки по умолчанию";
$MESS["CMDESKTOP_TDEF_CLEAR"] = "Сбросить текущие настройки";
$MESS["CMDESKTOP_TDEF_CANCEL"] = "Отмена";
$MESS["CMDESKTOP_TDEF_DELETE"] = "Удалить";
$MESS["CMDESKTOP_TDEF_HIDE"] = "Скрыть/показать";
$MESS["CMDESKTOP_TDEF_COLUMN_WIDTH"] = "Ширина столбца (px или %) #";
$MESS["CMDESKTOP_TDEF_GADGET_SETTINGS_DIALOG_TITLE"] = "Настройки гаджета";
$MESS["CMDESKTOP_TDEF_ADMIN_TITLE"] = "Рабочий стол: #TITLE#";
$MESS["CMDESKTOP_TDEF_ADMIN_TITLE_DEFAULT"] = "Рабочий стол #NUM#";
$MESS["CMDESKTOP_TDEF_PUBLIC"] = "Шаблон admin нельзя использовать в публичной части сайта";
?>