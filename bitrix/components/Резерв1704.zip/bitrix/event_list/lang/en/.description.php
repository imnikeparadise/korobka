<?
$MESS["EVENT_LIST_NAME"] = "Change Log";
$MESS["EVENT_LIST_DESCRIPTION"] = "Displays the change log.";
?>