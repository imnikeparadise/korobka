<?
$MESS["EVENT_LIST_FILTER_SETTINGS"] = "Filter Parameters";
$MESS["EVENT_LIST_LOG_CNT"] = "Records per page";
$MESS["EVENT_LIST_FILTER"] = "Filter Items";
$MESS["EVENT_LIST_USER_PATH"] = "User Profile Path Template";
$MESS["EVENT_LIST_FORUM_PATH"] = "Forum Path Template";
$MESS["EVENT_LIST_FORUM_TOPIC_PATH"] = "Forum Topic Path Template";
$MESS["EVENT_LIST_FORUM_MESSAGE_PATH"] = "Forum Post Path Template";
?>