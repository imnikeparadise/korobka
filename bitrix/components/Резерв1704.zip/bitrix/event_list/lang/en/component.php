<?
$MESS["MAIN_EVENTLOG_USER_AUTHORIZE"] = "Log on successful";
$MESS["MAIN_EVENTLOG_USER_LOGIN"] = "Log on errors";
$MESS["MAIN_EVENTLOG_USER_LOGINBYHASH_FAILED"] = "Logon error with saved authentication";
$MESS["MAIN_EVENTLOG_USER_LOGOUT"] = "Log out";
$MESS["MAIN_EVENTLOG_USER_REGISTER"] = "New user registration";
$MESS["MAIN_EVENTLOG_USER_REGISTER_FAIL"] = "Registration error";
$MESS["MAIN_EVENTLOG_USER_INFO"] = "Password change request";
$MESS["MAIN_EVENTLOG_USER_PASSWORD_CHANGED"] = "User password change";
$MESS["MAIN_EVENTLOG_USER_DELETE"] = "Delete user";
$MESS["MAIN_EVENTLOG_MP_MODULE_INSTALLED"] = "Marketplace solution has been installed";
$MESS["MAIN_EVENTLOG_MP_MODULE_UNINSTALLED"] = "Marketplace solution has been uninstalled";
$MESS["MAIN_EVENTLOG_MP_MODULE_DELETED"] = "Marketplace solution has been deleted";
$MESS["MAIN_EVENTLOG_MP_MODULE_DOWNLOADED"] = "Marketplace solution has been downloaded";
$MESS["MAIN_EVENTLOG_GROUP"] = "User's groups modified";
$MESS["MAIN_EVENTLOG_GROUP_POLICY"] = "Group security policy modified";
$MESS["MAIN_EVENTLOG_MODULE"] = "Module's group access permission changed";
$MESS["MAIN_EVENTLOG_FILE"] = "File access permission changed";
$MESS["MAIN_EVENTLOG_TASK"] = "Access level changed";
?>