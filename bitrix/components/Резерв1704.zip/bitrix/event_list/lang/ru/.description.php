<?
$MESS ['EVENT_LIST_NAME'] = "Журнал изменений";
$MESS ['EVENT_LIST_DESCRIPTION'] = "Выводит журнал изменений";
?>