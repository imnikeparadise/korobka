<?
$MESS ['EVENT_LIST_FILTER_SETTINGS'] = "Настройка фильтра";
$MESS ['EVENT_LIST_LOG_CNT'] = "Количество отображаемых записей на странице";
$MESS ['EVENT_LIST_FILTER'] = "Элементы в фильтре";
$MESS ['EVENT_LIST_USER_PATH'] = "Шаблон пути к странице пользователя";
$MESS ['EVENT_LIST_FORUM_PATH'] = "Шаблон пути к форуму";
$MESS ['EVENT_LIST_FORUM_TOPIC_PATH'] = "Шаблон пути к теме форума";
$MESS ['EVENT_LIST_FORUM_MESSAGE_PATH'] = "Шаблон пути к сообщению форума";
?>