<?
$MESS["MAIN_EVENTLOG_USER_AUTHORIZE"] = "Успешный вход";
$MESS["MAIN_EVENTLOG_USER_LOGIN"] = "Ошибки входа";
$MESS["MAIN_EVENTLOG_USER_LOGINBYHASH_FAILED"] = "Ошибка входа при сохраненной авторизации";
$MESS["MAIN_EVENTLOG_USER_LOGOUT"] = "Выход из системы";
$MESS["MAIN_EVENTLOG_USER_REGISTER"] = "Регистрация нового пользователя";
$MESS["MAIN_EVENTLOG_USER_REGISTER_FAIL"] = "Ошибка регистрации";
$MESS["MAIN_EVENTLOG_USER_INFO"] = "Запрос на смену пароля пользователя";
$MESS["MAIN_EVENTLOG_USER_PASSWORD_CHANGED"] = "Смена пароля пользователя";
$MESS["MAIN_EVENTLOG_USER_DELETE"] = "Удаление пользователя";
$MESS["MAIN_EVENTLOG_MP_MODULE_INSTALLED"] = "Решение Маркетплейс установленно";
$MESS["MAIN_EVENTLOG_MP_MODULE_UNINSTALLED"] = "Решение Маркетплейс удалено";
$MESS["MAIN_EVENTLOG_MP_MODULE_DELETED"] = "Решение Маркетплейс стерто";
$MESS["MAIN_EVENTLOG_MP_MODULE_DOWNLOADED"] = "Решение Маркетплейс скачано";
$MESS["MAIN_EVENTLOG_GROUP"] = "Изменены группы пользователя";
$MESS["MAIN_EVENTLOG_GROUP_POLICY"] = "Изменена политика безопасности группы";
$MESS["MAIN_EVENTLOG_MODULE"] = "Изменен доступ группы к модулю";
$MESS["MAIN_EVENTLOG_FILE"] = "Изменен доступ к файлу";
$MESS["MAIN_EVENTLOG_TASK"] = "Изменен уровень доступа";
?>