<?
$MESS["EVENT_LIST_SUBMIT"] = "Выбрать";
$MESS["EVENT_LIST_FILTER_CREATED_BY"] = "Автор";
$MESS["EVENT_LIST_FILTER_DATE"] = "Дата";
$MESS["EVENT_LIST_FILTER_FEATURES_TITLE"] = "События";
$MESS["EVENT_LIST_FILTER_TITLE"] = "Фильтр";
$MESS["EVENT_LIST_NO_UPDATES"] = "Нет обновлений.";
$MESS["EVENT_LIST_PAGE_NAV"] = "Записи на странице";
$MESS["EVENT_LIST_DATE_FILTER_DAYS"] = "дн.";
$MESS["EVENT_LIST_FILTER_SHOW"] = "показать";
$MESS["EVENT_LIST_FILTER_HIDE"] = "скрыть";
$MESS["EVENT_LIST_NO_ACTIVE_FEATURES_ERROR"] = "Не заданы события в фильтре для отображения";
?>