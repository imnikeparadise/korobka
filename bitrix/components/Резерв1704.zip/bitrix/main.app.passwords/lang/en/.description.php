<?
$MESS["main_app_passwords_comp_name"] = "Application passwords";
$MESS["main_app_passwords_comp_desc"] = "Manage application passwords";
$MESS["main_app_passwords_comp_user"] = "User";
?>