<?
$MESS["main_app_passwords_ajax_error"] = "Error processing request.";
$MESS["main_app_passwords_ajax_error_auth"] = "You are not logged in.";
$MESS["main_app_passwords_ajax_error_sess"] = "Your session has expired.";
$MESS["main_app_passwords_ajax_deleted"] = "Password has been deleted.";
$MESS["main_app_passwords_ajax_no_app"] = "No application is specified.";
?>