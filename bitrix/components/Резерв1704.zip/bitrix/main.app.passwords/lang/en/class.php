<?
$MESS["MAIN_PASSWORDS_TITLE"] = "Application passwords";
$MESS["main_app_passwords_auth"] = "You need to be logged in to manage application passwords.";
?>