<?
$MESS["main_app_passwords_comp_name"] = "Пароли приложений";
$MESS["main_app_passwords_comp_desc"] = "Управление паролями приложений";
$MESS["main_app_passwords_comp_user"] = "Пользователь";
?>