<?
$MESS["main_app_passwords_ajax_error"] = "Произошла ошибка при обработке запроса.";
$MESS["main_app_passwords_ajax_error_auth"] = "Вы должны быть авторизованы.";
$MESS["main_app_passwords_ajax_error_sess"] = "Ваша сессия истекла.";
$MESS["main_app_passwords_ajax_deleted"] = "Пароль успешно удален.";
$MESS["main_app_passwords_ajax_no_app"] = "Не указано приложение.";
?>