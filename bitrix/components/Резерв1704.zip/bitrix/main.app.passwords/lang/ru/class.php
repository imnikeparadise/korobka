<?
$MESS["MAIN_PASSWORDS_TITLE"] = "Пароли приложений";
$MESS["main_app_passwords_auth"] = "Вы должны быть авторизованы, чтобы работать с паролями приложений.";
?>