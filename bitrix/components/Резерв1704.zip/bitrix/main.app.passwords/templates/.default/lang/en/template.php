<?
$MESS["main_app_pass_del"] = "Delete";
$MESS["main_app_pass_title"] = "Application passwords";
$MESS["main_app_pass_text1"] = "To synchronize your data with external applications securely, use a special password which you can obtain on this page.";
$MESS["main_app_pass_text2"] = "Each of these tools support a range of applications supporting synchronization. Select an application for which you want to configure data transfer.";
$MESS["main_app_pass_created"] = "Created on";
$MESS["main_app_pass_last"] = "Last visit";
$MESS["main_app_pass_last_ip"] = "Last IP";
$MESS["main_app_pass_manage"] = "Manage";
$MESS["main_app_pass_link"] = "Link to";
$MESS["main_app_pass_comment"] = "Comment";
$MESS["main_app_pass_other"] = "Other";
$MESS["main_app_pass_comment_ph"] = "Add description";
$MESS["main_app_pass_get_pass"] = "Get password";
$MESS["main_app_pass_create_pass"] = "Create password";
$MESS["main_app_pass_create_pass_text"] = "Use this password to synchronize with the selected application.
	Password may not be kept in open form; therefore it is only available when obtained by the user.
	Don't close the window until you have copied or entered your password.";
$MESS["main_app_pass_create_pass_close"] = "Close";
$MESS["main_app_pass_del_pass"] = "Are you sure you want to delete the password?";
$MESS["main_app_pass_del_pass_text"] = "Synchronization will be aborted because the application will be unable to access data due to authentication error.";
$MESS["main_app_pass_cancel"] = "Cancel";
?>