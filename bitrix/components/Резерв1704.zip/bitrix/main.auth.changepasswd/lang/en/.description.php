<?
$MESS["MAIN_AUTH_CHD_DESCR"] = "Stand-alone password change form";
$MESS["MAIN_AUTH_CHD_GROUP_NAME"] = "User";
$MESS["MAIN_AUTH_CHD_TITLE"] = "Change password";
?>