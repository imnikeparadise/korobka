<?
$MESS["MAIN_AUTH_CHD_AUTH_AUTH_PASSWORD_URL"] = "Authentication page";
$MESS["MAIN_AUTH_CHD_AUTH_REGISTER_URL"] = "Registration page";
?>