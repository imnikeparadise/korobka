<?
$MESS["MAIN_AUTH_CHD_ERR_DECODE"] = "Password decryption error (#ERRCODE#).";
$MESS["MAIN_AUTH_CHD_SESS_EXPIRED"] = "Your session has expired. Please authorize again.";
?>