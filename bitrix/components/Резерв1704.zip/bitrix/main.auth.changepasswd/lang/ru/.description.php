<?php
$MESS['MAIN_AUTH_CHD_TITLE'] = 'Смена пароля';
$MESS['MAIN_AUTH_CHD_DESCR'] = 'Отдельная форма смены пароля пользователем';
$MESS['MAIN_AUTH_CHD_GROUP_NAME'] = 'Пользователь';