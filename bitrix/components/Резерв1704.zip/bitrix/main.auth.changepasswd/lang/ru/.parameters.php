<?php
$MESS['MAIN_AUTH_CHD_AUTH_AUTH_PASSWORD_URL'] = 'Страница для авторизации';
$MESS['MAIN_AUTH_CHD_AUTH_REGISTER_URL'] = 'Страница для регистрации';