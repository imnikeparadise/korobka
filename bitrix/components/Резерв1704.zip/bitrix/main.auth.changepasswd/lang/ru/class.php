<?php
$MESS['MAIN_AUTH_CHD_SESS_EXPIRED'] = 'Ваша сессия истекла, повторите попытку авторизации.';
$MESS['MAIN_AUTH_CHD_ERR_DECODE'] = 'Ошибка при дешифровании пароля (#ERRCODE#).';