<?
$MESS["MAIN_AUTH_CHD_FIELD_CAPTCHA"] = "Type the characters you see on the picture";
$MESS["MAIN_AUTH_CHD_FIELD_CHECKWORD"] = "Checkword";
$MESS["MAIN_AUTH_CHD_FIELD_LOGIN"] = "Login";
$MESS["MAIN_AUTH_CHD_FIELD_PASS"] = "Password";
$MESS["MAIN_AUTH_CHD_FIELD_PASS2"] = "Confirm password";
$MESS["MAIN_AUTH_CHD_FIELD_SUBMIT"] = "Change password";
$MESS["MAIN_AUTH_CHD_HEADER"] = "Change password";
$MESS["MAIN_AUTH_CHD_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["MAIN_AUTH_CHD_SUCCESS"] = "You are registered and logged in successfully.";
$MESS["MAIN_AUTH_CHD_URL_AUTH_URL"] = "Log in";
$MESS["MAIN_AUTH_CHD_URL_REGISTER_URL"] = "Register";
?>