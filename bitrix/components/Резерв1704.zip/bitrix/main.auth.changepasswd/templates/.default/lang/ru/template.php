<?php
$MESS['MAIN_AUTH_CHD_SUCCESS'] = 'Вы зарегистрированы и успешно авторизовались.';
$MESS['MAIN_AUTH_CHD_HEADER'] = 'Смена пароля';
$MESS['MAIN_AUTH_CHD_FIELD_LOGIN'] = 'Логин';
$MESS['MAIN_AUTH_CHD_FIELD_CHECKWORD'] = 'Контрольная строка';
$MESS['MAIN_AUTH_CHD_FIELD_PASS'] = 'Пароль';
$MESS['MAIN_AUTH_CHD_FIELD_PASS2'] = 'Подтверждение пароля';
$MESS['MAIN_AUTH_CHD_SECURE_NOTE'] = 'Перед отправкой формы авторизации пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.';
$MESS['MAIN_AUTH_CHD_FIELD_CAPTCHA'] = 'Введите слово на картинке';
$MESS['MAIN_AUTH_CHD_FIELD_SUBMIT'] = 'Изменить пароль';
$MESS['MAIN_AUTH_CHD_URL_AUTH_URL'] = 'Авторизоваться';
$MESS['MAIN_AUTH_CHD_URL_REGISTER_URL'] = 'Зарегистрироваться';