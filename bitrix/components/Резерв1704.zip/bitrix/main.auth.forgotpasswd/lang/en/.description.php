<?
$MESS["MAIN_AUTH_PWD_DESCR"] = "Stand-alone password request form";
$MESS["MAIN_AUTH_PWD_GROUP_NAME"] = "User";
$MESS["MAIN_AUTH_PWD_TITLE"] = "Request password";
?>