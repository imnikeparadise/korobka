<?
$MESS["MAIN_AUTH_PWD_AUTH_AUTH_PASSWORD_URL"] = "Authentication page";
$MESS["MAIN_AUTH_PWD_AUTH_REGISTER_URL"] = "Registration page";
?>