<?php
$MESS['MAIN_AUTH_PWD_TITLE'] = 'Запрос пароля';
$MESS['MAIN_AUTH_PWD_DESCR'] = 'Отдельная форма запроса пароля пользователем';
$MESS['MAIN_AUTH_PWD_GROUP_NAME'] = 'Пользователь';