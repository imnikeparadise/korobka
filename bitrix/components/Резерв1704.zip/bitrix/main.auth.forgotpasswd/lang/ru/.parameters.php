<?php
$MESS['MAIN_AUTH_PWD_AUTH_AUTH_PASSWORD_URL'] = 'Страница для авторизации';
$MESS['MAIN_AUTH_PWD_AUTH_REGISTER_URL'] = 'Страница для регистрации';