<?
$MESS["MAIN_AUTH_PWD_FIELD_CAPTCHA"] = "Type the characters you see on the picture";
$MESS["MAIN_AUTH_PWD_FIELD_EMAIL"] = "Email";
$MESS["MAIN_AUTH_PWD_FIELD_LOGIN"] = "Login";
$MESS["MAIN_AUTH_PWD_FIELD_SUBMIT"] = "Send";
$MESS["MAIN_AUTH_PWD_HEADER"] = "Send checkword";
$MESS["MAIN_AUTH_PWD_NOTE"] = "Enter your login or email if the password is forgotten. Your registration data and the checkword to reset your password will be sent to your email.";
$MESS["MAIN_AUTH_PWD_OR"] = "or";
$MESS["MAIN_AUTH_PWD_SUCCESS"] = "You are registered and logged in successfully.";
$MESS["MAIN_AUTH_PWD_URL_AUTH_URL"] = "Log in";
$MESS["MAIN_AUTH_PWD_URL_REGISTER_URL"] = "Register";
?>