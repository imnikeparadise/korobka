<?php
$MESS['MAIN_AUTH_PWD_SUCCESS'] = 'Вы зарегистрированы и успешно авторизовались.';
$MESS['MAIN_AUTH_PWD_HEADER'] = 'Выслать контрольную строку';
$MESS['MAIN_AUTH_PWD_NOTE'] = 'Если вы забыли пароль, введите логин или E-Mail. Контрольная строка для смены пароля, а также ваши регистрационные данные, будут высланы вам по E-Mail.';
$MESS['MAIN_AUTH_PWD_FIELD_LOGIN'] = 'Логин';
$MESS['MAIN_AUTH_PWD_OR'] = 'или';
$MESS['MAIN_AUTH_PWD_FIELD_EMAIL'] = 'E-Mail';
$MESS['MAIN_AUTH_PWD_FIELD_CAPTCHA'] = 'Введите слово на картинке';
$MESS['MAIN_AUTH_PWD_FIELD_SUBMIT'] = 'Выслать';
$MESS['MAIN_AUTH_PWD_URL_AUTH_URL'] = 'Авторизоваться';
$MESS['MAIN_AUTH_PWD_URL_REGISTER_URL'] = 'Зарегистрироваться';