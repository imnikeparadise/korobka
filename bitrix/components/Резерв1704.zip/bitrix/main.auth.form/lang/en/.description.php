<?
$MESS["MAIN_AUTH_FORM_DESCR"] = "Stand-alone user login form";
$MESS["MAIN_AUTH_FORM_GROUP_NAME"] = "User";
$MESS["MAIN_AUTH_FORM_TITLE"] = "Log-in form";
?>