<?
$MESS["MAIN_AUTH_FORM_AUTH_FORGOT_PASSWORD_URL"] = "Password recovery page";
$MESS["MAIN_AUTH_FORM_AUTH_REGISTER_URL"] = "Registration page";
$MESS["MAIN_AUTH_FORM_AUTH_SUCCESS_URL"] = "Login successful page";
?>