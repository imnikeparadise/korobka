<?
$MESS["MAIN_AUTH_FORM_ERR_DECODE"] = "Password decryption error (#ERRCODE#).";
$MESS["MAIN_AUTH_FORM_SESS_EXPIRED"] = "Your session has expired. Please authorize again.";
?>