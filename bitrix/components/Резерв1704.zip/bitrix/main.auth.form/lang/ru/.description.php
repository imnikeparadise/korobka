<?php
$MESS['MAIN_AUTH_FORM_TITLE'] = 'Авторизация';
$MESS['MAIN_AUTH_FORM_DESCR'] = 'Отдельная форма авторизации пользователя';
$MESS['MAIN_AUTH_FORM_GROUP_NAME'] = 'Пользователь';