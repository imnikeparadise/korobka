<?php
$MESS['MAIN_AUTH_FORM_AUTH_FORGOT_PASSWORD_URL'] = 'Страница для восстановления пароля';
$MESS['MAIN_AUTH_FORM_AUTH_REGISTER_URL'] = 'Страница для регистрации';
$MESS['MAIN_AUTH_FORM_AUTH_SUCCESS_URL'] = 'Страница после успешной авторизации';