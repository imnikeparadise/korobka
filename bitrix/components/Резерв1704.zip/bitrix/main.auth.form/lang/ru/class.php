<?php
$MESS['MAIN_AUTH_FORM_SESS_EXPIRED'] = 'Ваша сессия истекла, повторите попытку авторизации.';
$MESS['MAIN_AUTH_FORM_ERR_DECODE'] = 'Ошибка при дешифровании пароля (#ERRCODE#).';