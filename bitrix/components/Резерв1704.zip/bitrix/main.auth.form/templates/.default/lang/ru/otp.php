<?php
$MESS['MAIN_AUTH_OTP_HEADER'] = 'Пожалуйста, введите ваш одноразовый пароль';
$MESS['MAIN_AUTH_OTP_FIELD_OTP'] = 'Одноразовый пароль';
$MESS['MAIN_AUTH_OTP_FIELD_CAPTCHA'] = 'Введите слово на картинке';
$MESS['MAIN_AUTH_OTP_FIELD_REMEMBER'] = 'Запомнить код на этом компьютере';
$MESS['MAIN_AUTH_OTP_FIELD_SUBMIT'] = 'Войти';
$MESS['MAIN_AUTH_OTP_URL_AUTH_URL'] = 'Авторизация';
$MESS['MAIN_AUTH_OTP_URL_REGISTER_URL'] = 'Регистрация';