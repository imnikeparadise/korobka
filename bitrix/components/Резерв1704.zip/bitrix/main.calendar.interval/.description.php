<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

$arComponentDescription = array(
	"NAME" => GetMessage("MAIN_INT_CALENDAR_COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("MAIN_INT_CALENDAR_COMPONENT_DESCR"),
	"ICON" => "/images/calendar.gif",
	"PATH" => array(
		"ID" => "utility",
	),
);
