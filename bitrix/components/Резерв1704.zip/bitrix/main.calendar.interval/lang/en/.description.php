<?
$MESS["MAIN_INT_CALENDAR_COMPONENT_NAME"] = "\"Calendar Range\" control";
$MESS["MAIN_INT_CALENDAR_COMPONENT_DESCR"] = "Allows a user to specify a date range.";
?>