<?
$MESS["COMP_INT_MAIN_CALENDAR_FORM_NAME"] = "Form name";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_NAME"] = "Field name";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_NAME_FINISH"] = "Name of the second interval field";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_VALUE"] = "Value of the first interval field";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_VALUE_FINISH"] = "Value of the second interval field";
$MESS["COMP_INT_MAIN_CALENDAR_SELECT"] = "Drop-down list name";
$MESS["COMP_INT_MAIN_CALENDAR_SELECT_VAL"] = "Drop-down list value";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_DAY"] = "Days field name";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_DAY_VAL"] = "Days field value";
?>