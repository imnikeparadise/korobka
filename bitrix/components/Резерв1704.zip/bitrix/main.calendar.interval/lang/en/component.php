<?
$MESS["interface_grid_no_no_no_2"] = "(no)";
$MESS["inerface_grid_today"] = "today";
$MESS["inerface_grid_yesterday"] = "yesterday";
$MESS["inerface_grid_tomorrow"] = "tomorrow";
$MESS["inerface_grid_week"] = "this week";
$MESS["inerface_grid_week_ago"] = "last week";
$MESS["inerface_grid_month"] = "this month";
$MESS["inerface_grid_month_ago"] = "last month";
$MESS["inerface_grid_last"] = "recent";
$MESS["inerface_grid_exact"] = "exactly";
$MESS["inerface_grid_later"] = "after";
$MESS["inerface_grid_earlier"] = "before";
$MESS["inerface_grid_interval"] = "date range";
?>