<?
$MESS ['MAIN_INT_CALENDAR_COMPONENT_NAME'] = "Элемент управления \"Календарь-интервал\"";
$MESS ['MAIN_INT_CALENDAR_COMPONENT_DESCR'] = "Ввод интервала даты/времени";
?>