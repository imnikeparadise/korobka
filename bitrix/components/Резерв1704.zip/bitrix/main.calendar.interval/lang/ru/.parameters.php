<?
$MESS ['COMP_INT_MAIN_CALENDAR_FORM_NAME'] = "Имя формы";
$MESS ['COMP_INT_MAIN_CALENDAR_INPUT_NAME'] = "Имя первого поля интервала";
$MESS ['COMP_INT_MAIN_CALENDAR_INPUT_NAME_FINISH'] = "Имя второго поля интервала";
$MESS ['COMP_INT_MAIN_CALENDAR_INPUT_VALUE'] = "Значение первого поля интервала";
$MESS ['COMP_INT_MAIN_CALENDAR_INPUT_VALUE_FINISH'] = "Значение второго поля интервала";
$MESS["COMP_INT_MAIN_CALENDAR_SELECT"] = "Имя выпадающего списка";
$MESS["COMP_INT_MAIN_CALENDAR_SELECT_VAL"] = "Значение выпадающего списка";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_DAY"] = "Имя поля дней";
$MESS["COMP_INT_MAIN_CALENDAR_INPUT_DAY_VAL"] = "Значение поля дней";
?>