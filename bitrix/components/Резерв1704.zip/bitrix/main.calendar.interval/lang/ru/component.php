<?
$MESS["interface_grid_no_no_no_2"] = "(нет)";
$MESS["inerface_grid_today"] = "сегодня";
$MESS["inerface_grid_yesterday"] = "вчера";
$MESS["inerface_grid_tomorrow"] = "завтра";
$MESS["inerface_grid_week"] = "эта неделя";
$MESS["inerface_grid_week_ago"] = "прошл. неделя";
$MESS["inerface_grid_month"] = "этот месяц";
$MESS["inerface_grid_month_ago"] = "прошл. месяц";
$MESS["inerface_grid_last"] = "за послед.";
$MESS["inerface_grid_exact"] = "точно";
$MESS["inerface_grid_later"] = "позже";
$MESS["inerface_grid_earlier"] = "раньше";
$MESS["inerface_grid_interval"] = "интервал";
?>