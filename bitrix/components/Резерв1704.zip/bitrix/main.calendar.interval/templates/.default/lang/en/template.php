<?
$MESS["inerface_grid_days"] = "days";
?>