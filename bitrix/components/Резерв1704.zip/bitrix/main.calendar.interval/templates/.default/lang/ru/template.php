<?
$MESS["inerface_grid_days"] = "дн.";
?>