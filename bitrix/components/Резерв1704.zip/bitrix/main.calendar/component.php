<?
if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();

CJSCore::Init(array('popup', 'date'));

$this->IncludeComponentTemplate();
?>