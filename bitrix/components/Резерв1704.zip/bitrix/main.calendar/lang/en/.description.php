<?
$MESS ['MAIN_CALENDAR_COMPONENT_NAME'] = "Calendar control";
$MESS ['MAIN_CALENDAR_COMPONENT_DESCR'] = "Date/Time settings";
?>