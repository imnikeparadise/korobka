<?
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT'] = "Show control";
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT_Y'] = "with input field";
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT_N'] = "only icon";
$MESS ['COMP_MAIN_CALENDAR_FORM_NAME'] = "Form name";
$MESS ['COMP_MAIN_CALENDAR_INPUT_NAME'] = "Field name";
$MESS ['COMP_MAIN_CALENDAR_INPUT_NAME_FINISH'] = "Name of the second interval field";
$MESS ['COMP_MAIN_CALENDAR_INPUT_VALUE'] = "Value of the first interval field";
$MESS ['COMP_MAIN_CALENDAR_INPUT_VALUE_FINISH'] = "Value of the second interval field";
$MESS ['COMP_MAIN_CALENDAR_SHOW_TIME'] = "Enable time controls";
$MESS ['COMP_MAIN_CALENDAR_HIDE_TIMEBAR'] = "Hide Time input field";
?>