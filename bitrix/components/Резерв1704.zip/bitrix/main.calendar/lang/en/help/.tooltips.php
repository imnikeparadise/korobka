<?
$MESS ['SHOW_INPUT_TIP'] = "Calendar display mode";
$MESS ['INPUT_NAME_TIP'] = "Name of the first field in range";
$MESS ['SHOW_TIME_TIP'] = "Allows to input time in the date field";
$MESS ['INPUT_VALUE_TIP'] = "Default value of the first value in range";
$MESS ['INPUT_NAME_FINISH_TIP'] = "Name of the last field in range";
$MESS ['INPUT_VALUE_FINISH_TIP'] = "Default value of the last value in range";
?>