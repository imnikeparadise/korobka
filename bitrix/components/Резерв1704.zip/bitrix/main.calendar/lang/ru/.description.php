<?
$MESS ['MAIN_CALENDAR_COMPONENT_NAME'] = "Элемент управления \"Календарь\"";
$MESS ['MAIN_CALENDAR_COMPONENT_DESCR'] = "Ввод даты/времени";
?>