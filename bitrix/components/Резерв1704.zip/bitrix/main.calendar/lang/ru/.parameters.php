<?
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT'] = "Показывать элемент управления";
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT_Y'] = "с полем ввода";
$MESS ['COMP_MAIN_CALENDAR_SHOW_INPUT_N'] = "только иконку";
$MESS ['COMP_MAIN_CALENDAR_FORM_NAME'] = "Имя формы";
$MESS ['COMP_MAIN_CALENDAR_INPUT_NAME'] = "Имя первого поля интервала";
$MESS ['COMP_MAIN_CALENDAR_INPUT_NAME_FINISH'] = "Имя второго поля интервала";
$MESS ['COMP_MAIN_CALENDAR_INPUT_VALUE'] = "Значение первого поля интервала";
$MESS ['COMP_MAIN_CALENDAR_INPUT_VALUE_FINISH'] = "Значение второго поля интервала";
$MESS ['COMP_MAIN_CALENDAR_SHOW_TIME'] = "Позволять вводить время";
$MESS ['COMP_MAIN_CALENDAR_HIDE_TIMEBAR'] = "Скрывать поле для ввода времени";
?>