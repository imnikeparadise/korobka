<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("MAIN_CLOCK_COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("MAIN_CLOCK_COMPONENT_DESCR"),
	"ICON" => "/images/clock.gif",
	"PATH" => array(
		"ID" => "utility",
	),
);
?>