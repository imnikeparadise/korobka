<?
$MESS ['MAIN_CLOCK_COMPONENT_NAME'] = "Time Settings control";
$MESS ['MAIN_CLOCK_COMPONENT_DESCR'] = "Component for convenient time settings with the use of analog clock interface";
?>