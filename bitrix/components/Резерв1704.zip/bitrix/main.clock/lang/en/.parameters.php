<?
$MESS ['COMP_CLOCK_INPUT_ID'] = "Input Field ID";
$MESS ['COMP_CLOCK_INPUT_NAME'] = "Input Field Name";
$MESS ['COMP_CLOCK_INPUT_TITLE'] = "Input Field tooltip";
$MESS ['COMP_CLOCK_INIT_TIME'] = "Start time (HH:MM)";
$MESS ['COMP_CLOCK_STEP'] = "Minimum step size to set time (minutes)";
?>