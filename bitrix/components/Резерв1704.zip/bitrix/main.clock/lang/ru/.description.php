<?
$MESS ['MAIN_CLOCK_COMPONENT_NAME'] = "Элемент управления \"Часы\"";
$MESS ['MAIN_CLOCK_COMPONENT_DESCR'] = "Компонент для удобного ввода времени с использованием часов";
?>