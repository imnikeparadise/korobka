<?
$MESS ['COMP_CLOCK_INPUT_ID'] = "ID поля ввода";
$MESS ['COMP_CLOCK_INPUT_NAME'] = "Имя поля ввода";
$MESS ['COMP_CLOCK_INPUT_TITLE'] = "Всплывающая подсказка на поле ввода";
$MESS ['COMP_CLOCK_INIT_TIME'] = "Стартовое время (HH:MM)";
$MESS ['COMP_CLOCK_STEP'] = "Минимальный шаг для задания времени, в минутах";
?>