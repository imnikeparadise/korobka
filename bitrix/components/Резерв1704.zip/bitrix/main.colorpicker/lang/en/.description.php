<?
$MESS ['MAIN_COLORPICKER_COMPONENT_NAME'] = "Color Picker control";
$MESS ['MAIN_COLORPICKER_COMPONENT_DESCR'] = "Color selection component";
?>