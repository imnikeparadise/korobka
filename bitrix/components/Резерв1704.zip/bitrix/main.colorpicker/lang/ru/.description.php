<?
$MESS ['MAIN_COLORPICKER_COMPONENT_NAME'] = "Элемент управления \"Палитра\"";
$MESS ['MAIN_COLORPICKER_COMPONENT_DESCR'] = "Компонент для выбора цвета";
?>