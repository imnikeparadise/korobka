<?
$MESS ['COMP_MAIN_COLORPICKER_SHOW_BUTTON'] = "Показывать кнопку";
$MESS ['COMP_MAIN_COLORPICKER_ID'] = "Идентификатор";
$MESS ['COMP_MAIN_COLORPICKER_NAME'] = "Название";
$MESS ['COMP_MAIN_COLORPICKER_NAME_DEFAULT'] = "Выбор цвета";
$MESS ['COMP_MAIN_COLORPICKER_ONSELECT'] = "Обработчик события выбора";
?>