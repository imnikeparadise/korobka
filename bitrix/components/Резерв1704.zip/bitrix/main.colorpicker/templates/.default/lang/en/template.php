<?
$MESS ['DefaultColor'] = "Default";
?>