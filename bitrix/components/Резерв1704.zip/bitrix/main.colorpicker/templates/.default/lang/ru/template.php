<?
$MESS ['DefaultColor'] = "По умолчанию";
?>