<?
$MESS ['MF_OK_MESSAGE'] = "Thank you. Your message is now being processed.";
$MESS ['MF_REQ_NAME'] = "Please type your name.";
$MESS ['MF_REQ_EMAIL'] = "Provide a reply-to e-mail address.";
$MESS ['MF_REQ_MESSAGE'] = "The message text is required.";
$MESS ['MF_EMAIL_NOT_VALID'] = "The e-mail address specified is invalid.";
$MESS ['MF_CAPTCHA_WRONG'] = "The CAPTCHA code you have typed is incorrect.";
$MESS ['MF_CAPTHCA_EMPTY'] = "The CAPTCHA code is required.";
$MESS ['MF_SESS_EXP'] = "Your session has expired. Please send your message again.";
?>