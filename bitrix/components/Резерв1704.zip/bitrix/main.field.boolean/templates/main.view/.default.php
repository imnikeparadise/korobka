<?php

if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/**
 * @var array $arResult
 */
?>

<span class="fields boolean field-wrap">
	<span class="fields boolean field-item">
  	<?= $arResult['valueTitle'] ?>
	</span>
</span>