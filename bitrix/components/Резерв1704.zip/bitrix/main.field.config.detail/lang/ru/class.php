<?php
$MESS["MAIN_FIELD_CONFIG_DETAIL_NO_ENTITY_ID_ERROR"] = "Не указан тип сущности";
$MESS["MAIN_FIELD_CONFIG_DETAIL_FIELD_NOT_FOUND_ERROR"] = "Пользовательское поле не найдено";
$MESS["MAIN_FIELD_CONFIG_DETAIL_DEFAULT_LABEL"] = "Новое поле";
$MESS["MAIN_FIELD_CONFIG_DETAIL_TITLE_EDIT"] = "Редактирование поля";
$MESS["MAIN_FIELD_CONFIG_DETAIL_TITLE_ADD"] = "Новое поле";