<?
$MESS["MAIN_FIELD_CONFIG_ALL_LANGUAGES"] = "Assign names in all languages";
$MESS["MAIN_FIELD_CONFIG_DELETE_CONFIRM"] = "Are you sure you want to delete this field? All data will be lost.";
$MESS["MAIN_FIELD_CONFIG_DELETE_SUCCESS"] = "Field has been deleted";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_ADD"] = "Add";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_DEFAULT"] = "Default value";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_DEFAULT_EMPTY"] = "value not specified";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_TITLE"] = "List items";
$MESS["MAIN_FIELD_CONFIG_MENU_ADDITIONAL"] = "More";
$MESS["MAIN_FIELD_CONFIG_MENU_COMMON"] = "Common";
$MESS["MAIN_FIELD_CONFIG_MENU_LABELS"] = "All languages";
$MESS["MAIN_FIELD_CONFIG_MENU_LIST"] = "List values";
$MESS["MAIN_FIELD_CONFIG_SETTINGS"] = "Settings";
?>