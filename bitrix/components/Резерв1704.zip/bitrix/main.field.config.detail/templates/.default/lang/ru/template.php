<?php
$MESS["MAIN_FIELD_CONFIG_ALL_LANGUAGES"] = "Задать названия для всех языков";
$MESS["MAIN_FIELD_CONFIG_DELETE_CONFIRM"] = "Вы уверены, что хотите удалить это поле? Все данные будут утеряны";
$MESS["MAIN_FIELD_CONFIG_DELETE_SUCCESS"] = "Поле успешно удалено";
$MESS["MAIN_FIELD_CONFIG_MENU_COMMON"] = "Общее";
$MESS["MAIN_FIELD_CONFIG_MENU_LABELS"] = "Все языки";
$MESS["MAIN_FIELD_CONFIG_MENU_ADDITIONAL"] = "Дополнительно";
$MESS["MAIN_FIELD_CONFIG_MENU_LIST"] = "Значения списка";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_TITLE"] = "Элементы списка";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_DEFAULT"] = "Значение по умолчанию";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_DEFAULT_EMPTY"] = "значение не задано";
$MESS["MAIN_FIELD_CONFIG_LIST_ITEMS_ADD"] = "Добавить";
$MESS["MAIN_FIELD_CONFIG_SETTINGS"] = "Настройки";