module.exports = {
	input: './src/mobile.js',
	output: {
		js: './mobile.js',
	},
	namespace: 'BX.Mobile.Field.String',
	//adjustConfigPhp: false,
};