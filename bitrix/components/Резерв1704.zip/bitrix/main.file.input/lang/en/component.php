<?
$MESS["MFI_ERR_NO_INPUT_NAME"] = "The field name is not specified (INPUT_NAME)";
?>