<?
$MESS["MFI_ERR_NO_INPUT_NAME"] = "Не указано имя поля (INPUT_NAME)";
?>