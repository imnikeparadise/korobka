<?
$MESS["MFI_CONFIRM"] = "Delete the file?";
$MESS["MFI_INPUT_CAPTION_ADD"] = "Add file";
$MESS["MFI_INPUT_CAPTION_ADD_IMAGE"] = "Add image";
$MESS["MFI_INPUT_CAPTION_REPLACE"] = "Replace file";
$MESS["MFI_INPUT_CAPTION_REPLACE_IMAGE"] = "Replace image";
$MESS["MFI_UPLOADING_ERROR"] = "File upload error.";
$MESS["MFI_NOTICE_1"] = "Select a file with the #ext# extension. File size must not exceed #size#.";
$MESS["MFI_NOTICE_2"] = "Select a file with the #ext# extension.";
$MESS["MFI_NOTICE_3"] = "File size must not exceed #size#.";
?>