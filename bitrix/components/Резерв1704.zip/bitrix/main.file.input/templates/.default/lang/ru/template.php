<?
$MESS["MFI_CONFIRM"] = "Удалить файл?";
$MESS["MFI_INPUT_CAPTION_ADD"] = "Добавить файл";
$MESS["MFI_INPUT_CAPTION_ADD_IMAGE"] = "Добавить изображение";
$MESS["MFI_INPUT_CAPTION_REPLACE"] = "Заменить файл";
$MESS["MFI_INPUT_CAPTION_REPLACE_IMAGE"] = "Заменить изображение";
$MESS["MFI_UPLOADING_ERROR"] = "Ошибка загрузки файла.";
$MESS["MFI_NOTICE_1"] = "Выберите файл с расширением (#ext#) и размером, не превышающим #size#.";
$MESS["MFI_NOTICE_2"] = "Выберите файл с расширением (#ext#).";
$MESS["MFI_NOTICE_3"] = "Выберите файл, размер которого не превышает #size#.";
?>