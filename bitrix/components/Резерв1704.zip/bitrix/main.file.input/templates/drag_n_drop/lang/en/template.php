<?
$MESS["BFDND_FILE_LOADING"] = "Loading";
$MESS["BFDND_FILE_EXISTS"] = "A file with this name already exists. You can still use the current folder, in which case the existing version of the document will be saved in the history.";
$MESS["BFDND_FILES"] = "Files:";
$MESS["BFDND_DROPHERE"] = "Drag and drop one or more files here";
$MESS["BFDND_SELECT_EXIST"] = "or select a file from your computer";
$MESS["BFDND_SELECT_LOCAL"] = "Upload files";
$MESS["BFDND_UPLOAD_ERROR"] = "Error saving the file.";
$MESS["BFDND_ACCESS_DENIED"] = "Access denied";
$MESS["BFDND_UPLOAD_IMAGES"] = "Upload images";
$MESS["BFDND_UPLOAD_FILES"] = "Upload files";
?>