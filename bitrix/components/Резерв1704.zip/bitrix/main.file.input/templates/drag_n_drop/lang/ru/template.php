<?
$MESS["BFDND_FILE_LOADING"] = "Загрузка";
$MESS["BFDND_FILE_EXISTS"] = "Файл с таким именем уже существует. Вы можете выбрать текущую папку, в этом случае старая версия файла будет сохранена в истории документа.";
$MESS["BFDND_UPLOAD_ERROR"] = "При сохранении файла произошла ошибка.";
$MESS["BFDND_FILES"] = "Файлы:";
$MESS["BFDND_DROPHERE"] = "Перетащите один или несколько файлов в эту область";
$MESS["BFDND_SELECT_EXIST"] = "или выберите файл на компьютере";
$MESS["BFDND_SELECT_LOCAL"] = "Загрузить файлы";
$MESS["BFDND_ACCESS_DENIED"] = "Доступ запрещен";
$MESS["BFDND_UPLOAD_IMAGES"] = "Загрузить картинки";
$MESS["BFDND_UPLOAD_FILES"] = "Загрузить файлы";

?>
