<?
$MESS ['MAIN_INCLUDE_COMPONENT_NAME'] = "Insert include area";
$MESS ['MAIN_INCLUDE_COMPONENT_DESCR'] = "Insert include area";
$MESS ['MAIN_INCLUDE_GROUP_NAME'] = "Include Areas";
?>