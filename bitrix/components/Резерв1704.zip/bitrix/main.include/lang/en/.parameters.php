<?
$MESS ['MAIN_INCLUDE_PAGE'] = "for page";
$MESS ['MAIN_INCLUDE_SECT'] = "for section";
$MESS ['MAIN_INCLUDE_FILE'] = "from file";
$MESS ['MAIN_INCLUDE_PARAMS'] = "Component parameters";
$MESS ['MAIN_INCLUDE_AREA_FILE_SHOW'] = "Show include area";
$MESS ['MAIN_INCLUDE_AREA_FILE_SUFFIX'] = "Filename suffix for include area";
$MESS ['MAIN_INCLUDE_AREA_FILE_RECURSIVE'] = "Include section areas recursively";
$MESS ['MAIN_INCLUDE_EDIT_TEMPLATE'] = "Default template for include area";
$MESS ['MAIN_INCLUDE_PATH'] = "Path to include area file";
?>