<?
$MESS["MAIN_INCLUDE_AREA_EDIT_page"] = "Edit page include area";
$MESS["MAIN_INCLUDE_AREA_EDIT_sect"] = "Edit section include area";
$MESS["MAIN_INCLUDE_AREA_EDIT_file"] = "Edit include area file";
$MESS["MAIN_INCLUDE_AREA_ADD_page"] = "Add include area to current page";
$MESS["MAIN_INCLUDE_AREA_ADD_sect"] = "Add include area to current section";
$MESS["MAIN_INCLUDE_AREA_ADD_file"] = "Add include area file";
$MESS["MAIN_INCLUDE_AREA_EDIT_page_NOEDITOR"] = "Edit page include area as PHP";
$MESS["MAIN_INCLUDE_AREA_EDIT_sect_NOEDITOR"] = "Edit section include area as PHP";
$MESS["MAIN_INCLUDE_AREA_EDIT_file_NOEDITOR"] = "Edit include area file as PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_page_NOEDITOR"] = "Add include area to page as PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_sect_NOEDITOR"] = "Add include area to current section as PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_file_NOEDITOR"] = "Add include area file as PHP";
$MESS["main_comp_include_edit"] = "Edit Area";
$MESS["main_comp_include_edit_php"] = "Edit Area As PHP";
$MESS["main_comp_include_add"] = "Add";
$MESS["main_comp_include_add_php"] = "Add As PHP";
$MESS["main_comp_include_add1"] = "Add Area";
$MESS["main_comp_include_add1_php"] = "Add Area As PHP";
?>