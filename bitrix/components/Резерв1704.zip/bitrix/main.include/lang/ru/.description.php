<?
$MESS ['MAIN_INCLUDE_COMPONENT_NAME'] = "Вставка включаемой области";
$MESS ['MAIN_INCLUDE_COMPONENT_DESCR'] = "Вставка включаемой области";
$MESS ['MAIN_INCLUDE_GROUP_NAME'] = "Включаемые области";
?>