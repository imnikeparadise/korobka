<?
$MESS ['MAIN_INCLUDE_PAGE'] = "для страницы";
$MESS ['MAIN_INCLUDE_SECT'] = "для раздела";
$MESS ['MAIN_INCLUDE_FILE'] = "из файла";
$MESS ['MAIN_INCLUDE_PARAMS'] = "Параметры компонента";
$MESS ['MAIN_INCLUDE_AREA_FILE_SHOW'] = "Показывать включаемую область";
$MESS ['MAIN_INCLUDE_AREA_FILE_SUFFIX'] = "Суффикс имени файла включаемой области";
$MESS ['MAIN_INCLUDE_AREA_FILE_RECURSIVE'] = "Рекурсивное подключение включаемых областей разделов";
$MESS ['MAIN_INCLUDE_EDIT_TEMPLATE'] = "Шаблон области по умолчанию";
$MESS ['MAIN_INCLUDE_PATH'] = "Путь к файлу области";
?>