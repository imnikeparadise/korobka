<?
$MESS["MAIN_INCLUDE_AREA_EDIT_page"] = "Редактировать включаемую область текущей страницы";
$MESS["MAIN_INCLUDE_AREA_EDIT_sect"] = "Редактировать включаемую область раздела";
$MESS["MAIN_INCLUDE_AREA_EDIT_file"] = "Редактировать файл включаемой области";
$MESS["MAIN_INCLUDE_AREA_ADD_page"] = "Добавить включаемую область для текущей страницы";
$MESS["MAIN_INCLUDE_AREA_ADD_sect"] = "Добавить включаемую область текущего раздела";
$MESS["MAIN_INCLUDE_AREA_ADD_file"] = "Создать файл включаемой области";
$MESS["MAIN_INCLUDE_AREA_EDIT_page_NOEDITOR"] = "Редактировать включаемую область текущей страницы как PHP";
$MESS["MAIN_INCLUDE_AREA_EDIT_sect_NOEDITOR"] = "Редактировать включаемую область раздела как PHP";
$MESS["MAIN_INCLUDE_AREA_EDIT_file_NOEDITOR"] = "Редактировать файл включаемой области как PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_page_NOEDITOR"] = "Добавить включаемую область для текущей страницы как PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_sect_NOEDITOR"] = "Добавить включаемую область текущего раздела как PHP";
$MESS["MAIN_INCLUDE_AREA_ADD_file_NOEDITOR"] = "Создать файл включаемой области как PHP";
$MESS["main_comp_include_edit"] = "Изменить область";
$MESS["main_comp_include_edit_php"] = "Изменить область как PHP";
$MESS["main_comp_include_add"] = "Добавить";
$MESS["main_comp_include_add_php"] = "Добавить как PHP";
$MESS["main_comp_include_add1"] = "Добавить область";
$MESS["main_comp_include_add1_php"] = "Добавить область как PHP";
?>