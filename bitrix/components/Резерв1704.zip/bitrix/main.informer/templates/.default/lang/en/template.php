<?
$MESS ['WD_NEXT_ADVICE'] = "Next Tip";
$MESS ['WD_PREV_ADVICE'] = "Previous Tip";
$MESS ['WD_BANNER_CLOSE'] = "Hide Tips";
?>