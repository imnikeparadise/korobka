<?
$MESS ['WD_NEXT_ADVICE'] = "следующий совет";
$MESS ['WD_PREV_ADVICE'] = "предыдущий совет";
$MESS ['WD_BANNER_CLOSE'] = "Закрыть подсказки";
?>