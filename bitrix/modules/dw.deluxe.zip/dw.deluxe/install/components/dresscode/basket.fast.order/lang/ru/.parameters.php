<?
	$MESS["SITE_ID"] = "ID сайта";
	$MESS["USE_MASKED"] = "Использовать маски для телефонов";
	$MESS["MASKED_FORMAT"] = "Формат маски для телефонов";
?>