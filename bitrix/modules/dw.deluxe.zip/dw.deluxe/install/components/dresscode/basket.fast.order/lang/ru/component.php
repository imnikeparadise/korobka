<?
	$MESS["FAST_VIEW_PRICES_FROM"] = "от ";
	$MESS["FAST_VIEW_PRICES_TO"] = " до ";
?>