<?
	$MESS["FAST_BASKET_HEADING"] = "Быстрый заказ";
	$MESS["FAST_BASKET_TEXT"] = "Оставьте Ваш номер телефона и мы свяжемся с Вами для подтверждения заказа";
	$MESS["FAST_BASKET_NAME_PLACEHOLDER"] = "Ваше имя";
	$MESS["FAST_BASKET_TELEPHONE_PLACEHOLDER"] = "Ваш телефон*";
	$MESS["FAST_BASKET_PERSONAL_INFO_LABEL"] = 'Я согласен на <a href="'.SITE_DIR.'personal-info/" class="pilink">обработку персональных данных.</a>*';
	$MESS["FAST_BASKET_SUBMIT"] = "Отправить заказ";
	$MESS["FAST_BASKET_SUCCESS_HEADING"] = "Заказ оформлен";
	$MESS["FAST_BASKET_SUCCESS_TEXT"] = "Ваш заказ успешно оформлен. В ближайшее время по указанному телефону с Вами свяжется наш менеджер.";
	$MESS["FAST_BASKET_SUCCESS_CLOSE"] = "Закрыть окно";
	$MESS["FAST_BASKET_ERROR_HEADING"] = "Ошибка оформления";
	$MESS["FAST_BASKET_ERROR_TEXT"] = "В процессе оформления заказа возникла ошибка, обратитесь пожалуйста в наш отдел продаж или оформите заказ заново.";
	$MESS["FAST_BASKET_ERROR_CLOSE"] = "Закрыть окно";
?>