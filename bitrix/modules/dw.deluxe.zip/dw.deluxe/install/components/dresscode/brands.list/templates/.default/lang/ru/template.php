<?
	$MESS["BRAND_LIST_HEADING"] = "Популярные производители товаров";	
	$MESS["BRAND_LIST_HEADING"] = "Популярные категории товаров";
	$MESS["BRAND_LIST_SHOW_MORE"] = "Показать ещё";
	$MESS["BRAND_LIST_SHOWS"] = "Показано";
	$MESS["BRAND_LIST_FROM"] = "из";
?>