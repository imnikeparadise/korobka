<?
$MESS ['CC_BCF_MODULE_NOT_INSTALLED'] = "Модуль Информационных блоков не установлен";
?>