<?
$MESS["CP_BCT_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "зеленая";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "желтая";
$MESS["CP_BCT_TPL_THEME_RED"] = "красная";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "темная";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Цветовая тема";
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Вид отображения";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "горизонтальный";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "вертикальный";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Позиция для отображения всплывающего блока с информацией о фильтрации";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "слева";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "справа";
$MESS["TP_BCSF_DISPLAY_ELEMENT_COUNT"] = "Показывать количество";
?>