<?
$MESS ['IBLOCK'] = "Инфоблок";
$MESS ['IBLOCK_TYPE'] = "Тип инфоблока";
$MESS["IBLOCK_PRICE_CODE"] = "Тип цены";
$MESS["LAZY_LOAD_PICTURES"] = "Использовать lazy load для изображений";
?>