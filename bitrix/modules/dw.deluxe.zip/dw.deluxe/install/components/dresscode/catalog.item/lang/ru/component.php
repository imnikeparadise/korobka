<?
	$MESS["CATALOG_ITEM_NOT_FOUND"] = "Товар не найден!";
?>