<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters["HIDE_AVAILABLE_TABB"] = array(
	"NAME" => GetMessage("HIDE_AVAILABLE_TAB"),
	"TYPE" => "CHECKBOX", 
	"PARENT" => "BASE",
	"DEFAULT" =>"N",
	"VALUE" => "Y"
);