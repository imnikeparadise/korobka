<?
	$MESS["NEW_HEADING"] = "Новые поступления";
	$MESS["ADDCART"] = "В корзину";
	$MESS["ADDSKU"] = "Уточнить";
	$MESS["ADDCOMPARE"] = "Сравнить";
	$MESS["ADDCOMPARED"] = " В списке сравнения";
	$MESS["AVAILABLE"] = "В наличии";
	$MESS["NOAVAILABLE"] = "Недоступно";
	$MESS["FROM"] = "от ";
	$MESS["ON_ORDER"] = "Под заказ";
	$MESS["GET_ALL_PRODUCT"] = "Все предложения";
	$MESS["ADDCART_LABEL"] = "В корзину";
	$MESS["FASTBACK_LABEL"] = "Купить в 1 клик";
	$MESS["WISHLIST_LABEL"] = "В избранное";
	$MESS["COMPARE_LABEL"] = "К сравнению";
	$MESS["FAST_VIEW_PRODUCT_LABEL"] = "Быстрый просмотр";
	$MESS["SHOW_MORE"] = "Показать ещё";
	$MESS["SHOWS"] = "Показано";
	$MESS["FROM"] = "из";
	$MESS["PRODUCT_TIMER_DAY_LABEL"] = "Дней";
	$MESS["PRODUCT_TIMER_HOUR_LABEL"] = "Часов";
	$MESS["PRODUCT_TIMER_MINUTE_LABEL"] = "Минут";
	$MESS["PRODUCT_TIMER_SECOND_LABEL"] = "Секунд";	
	$MESS["REQUEST_PRICE_LABEL"] = "Цена по запросу";
	$MESS["REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
	$MESS["PRODUCT_SUBSCRIBE_LABEL"] = "Подписаться";
?>