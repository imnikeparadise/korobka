<?$APPLICATION->AddHeadScript($templateFolder."/js/morePicturesCarousel.js");?>
<?$APPLICATION->AddHeadScript($templateFolder."/js/pictureSlider.js");?>
<?$APPLICATION->AddHeadScript($templateFolder."/js/zoomer.js");?>