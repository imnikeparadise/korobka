<?
	$MESS["SPECIAL_TIME_LEFT"] = "До конца акции осталось";
	$MESS["TIMER_DAY_LABEL"] = "Дней";
	$MESS["TIMER_HOUR_LABEL"] = "Часов";
	$MESS["TIMER_MINUTE_LABEL"] = "Минут";
	$MESS["TIMER_SECOND_LABEL"] = "Секунд";
	$MESS["MORE_LINK_LABEL"] = "Подробнее";
	$MESS["FAST_VIEW_PRODUCT_LABEL"] = "Быстрый просмотр";
	$MESS["REQUEST_PRICE_LABEL"] = "Цена по запросу";
	$MESS["REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
?>