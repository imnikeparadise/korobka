<?
	$MESS["PRODUCT_ID_LABEL"] = "ID товара";
	$MESS["IBLOCK_PRICE_CODE"] = "Тип цены";
?>