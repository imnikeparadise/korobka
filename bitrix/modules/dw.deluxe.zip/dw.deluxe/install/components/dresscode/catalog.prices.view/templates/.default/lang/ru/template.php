<?
	$MESS["APP_PRODUCT_PRICE_VARIANT_HEADING"] = "Возможные варианты цен на этот товар";
	$MESS["APP_PRODUCT_PRICE_VARIANT_LINK_MORE"] = "Узнать больше";
	$MESS["APP_PRODUCT_PRICE_VARIANT_AVAILABLE_PRICE_LABEL"] = "Ваша цена";
?>