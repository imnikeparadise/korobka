<?
	$MESS["CATALOG_ITEM_NOT_FOUND"] = "РўРѕРІР°СЂ РЅРµ РЅР°Р№РґРµРЅ!";
?>