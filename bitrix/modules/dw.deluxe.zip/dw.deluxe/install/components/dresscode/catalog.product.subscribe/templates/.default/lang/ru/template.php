<?
	$MESS["CATALOG_SUBSCRIBE_HEADING"] = "Подписаться на товар";
	$MESS["CATALOG_SUBSCRIBE_TEXT"] = "Оставьте Ваш email и мы уведомим Вас о поступлении данного товара письмом на указанную электронную почту.";
	$MESS["CATALOG_SUBSCRIBE_FORM_EMAIL"] = "Электронная почта";
	$MESS["CATALOG_SUBSCRIBE_SUBMIT"] = "Подписаться";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_HEADING"] = "Подписка оформлена";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_TEXT"] = "Подписка на данный товар успешно оформлена. Когда товар появится в продаже, Вам придет уведомление на указанную почту.";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_CLOSE"] = "Закрыть окно";
	$MESS["CATALOG_SUBSCRIBE_ERROR_HEADING"] = "Ошибка оформления";
	$MESS["CATALOG_SUBSCRIBE_ERROR_TEXT"] = "В процессе оформления подписки возникла ошибка, обратитесь пожалуйста в наш отдел продаж или оформите подписку заново.";
	$MESS["CATALOG_SUBSCRIBE_ERROR_CLOSE"] = "Закрыть окно";
?>