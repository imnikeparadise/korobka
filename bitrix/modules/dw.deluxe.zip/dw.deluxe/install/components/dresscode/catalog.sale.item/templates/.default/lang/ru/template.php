<?
	$MESS["NEW_HEADING"] = "Новые поступления";
	$MESS["BIND_ACTION_LABEL"] = "Товар участвует в акции:";
?>