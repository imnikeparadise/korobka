<?
	$MESS["CATALOG_SECTION_NOT_FOUND"] = "Раздел не найден!";
?>