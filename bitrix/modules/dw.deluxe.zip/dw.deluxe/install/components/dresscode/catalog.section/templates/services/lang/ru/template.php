<?
	$MESS["SERVICES_LABEL"] = "Дополнительные услуги";
?>