<?
$MESS["STORE_ID"] = "ID склада";
$MESS["MAP_TYPE"] = "Тип карты";
?>