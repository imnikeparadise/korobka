<?
$MESS ['CATALOG_MODULE_NOT_INSTALL'] = "Модуль Торговый Каталог не установлен.";
$MESS ['STORE_NOT_EXIST'] = "Такого склада не существует";
?>