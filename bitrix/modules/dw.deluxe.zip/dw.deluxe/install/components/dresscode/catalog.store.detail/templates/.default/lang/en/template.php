<?
$MESS["BACK_STORE_LIST"] = "All warehouses";
$MESS["S_NAME"] = "Name:";
$MESS["S_PHONE"] = "Phone:";
$MESS["S_ADDRESS"] = "Address:";
$MESS["S_SCHEDULE"] = "Business hours:";
?>