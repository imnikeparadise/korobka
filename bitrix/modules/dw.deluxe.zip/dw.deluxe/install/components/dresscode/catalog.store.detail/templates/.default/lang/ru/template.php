<?
$MESS["BACK_STORE_LIST"] = "К списку складов";
$MESS["S_NAME"] = "Название:";
$MESS["S_PHONE"] = "Телефон:";
$MESS["S_ADDRESS"] = "Адрес:";
$MESS["S_SCHEDULE"] = "График работы:";
?>
