<?
$MESS["SHOW_SCHEDULE"] = "Отображать график работы";
$MESS["SHOW_PHONE"] = "Отображать телефон";
$MESS["STORE_PATH"] = "Шаблон пути к каталогу STORE(относительно корня)";
$MESS["MAP_TYPE"] = "Тип карты";
?>