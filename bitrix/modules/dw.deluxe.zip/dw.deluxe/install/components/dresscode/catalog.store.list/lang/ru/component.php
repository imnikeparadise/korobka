<?
$MESS["CATALOG_MODULE_NOT_INSTALL"] = "Модуль Торговый Каталог не установлен.";
$MESS["SCS_DEFAULT_TITLE"] = "Склады";
?>