<?
$MESS["STORES_LIST_SCHEDULE"] = "График работы";
$MESS["STORES_LIST_NAME"] = "Название и адрес";
$MESS["STORES_LIST_PICTURE"] = "Изображение";
$MESS["STORES_LIST_TELEPHONE"] = "Телефон";
$MESS["STORES_LIST_EMAIL"] = "Email";
?>
