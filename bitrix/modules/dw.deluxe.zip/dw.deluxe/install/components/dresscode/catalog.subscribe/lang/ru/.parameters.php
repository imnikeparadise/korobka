<?
	$MESS["CATALOG_SUBSCRIBE_RUBRIC_ID"] = "Рубрика";
	$MESS["CATALOG_SUBSCRIBE_SITE_ID"] = "Идентификатор сайта";
?>