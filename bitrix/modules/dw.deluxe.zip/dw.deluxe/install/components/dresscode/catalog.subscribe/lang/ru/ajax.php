<?
	$MESS["CATALOG_SUBSCRIBE_TRANSMITTED_DATA_ERROR"] = "Некорректно заполнены поля";
	$MESS["CATALOG_SUBSCRIBE_ACTION_TYPE_ERROR"] = "Ошибка при передачи параметров (actionType)";
?>