<?
	$MESS["CATALOG_SUBSCRIBE_EMAIL"] = "Ваш email";
	$MESS["CATALOG_SUBSCRIBE_SEND"] = "Подписаться";
	$MESS["CATALOG_SUBSCRIBE_PERSONAL_INFO"] = "Я согласен на <a href=\"#SITE_DIR#personal-info/\" class=\"pilink\" target=\"_blank\">обработку персональных данных.</a>*";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_HEADING"] = "Подтвердите подписку";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_TEXT"] = "Код подтверждения отправлен на указанную электронную почту. Перейдите по ссылке в письме для подтверждения подписки";
	$MESS["CATALOG_SUBSCRIBE_SUCCESS_CLOSE"] = "Закрыть окно";
	$MESS["CATALOG_SUBSCRIBE_ERROR_HEADING"] = "Произошла ошибка";
	$MESS["CATALOG_SUBSCRIBE_ERROR_TEXT"] = "Не удалось успешно подписаться на рассылку.";
?>