<?
	$MESS["CATALOG_TAGS_META_HEADING"] = "Заголовок";
	$MESS["CATALOG_TAGS_META_TITLE"] = "Заголовок окна браузера";
	$MESS["CATALOG_TAGS_META_KEYWORDS"] = "Meta keywords (Ключевые слова)";
	$MESS["CATALOG_TAGS_META_DESCRIPTION"] = "Meta description (Описание)";
	$MESS["CATALOG_TAG_NAME"] = "Имя тега";
?>