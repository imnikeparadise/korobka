<?
$MESS["IBLOCK_ID"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип Инфоблока";
$MESS["SECTION_ID"] = "ID раздела";
$MESS["SECTION_CODE"] = "Символьный код раздела";
$MESS["SECTION_CODE_PATH"] = "Путь из символьных кодов раздела";
$MESS["SEF_FOLDER"] = "Каталог ЧПУ (относительно корня сайта):";
$MESS["HIDE_NOT_AVAILABLE"] = "Не учитывать недоступные товары для построения тегов";
$MESS["INCLUDE_SUBSECTIONS"] = "Обрабатывать элементы подразделов раздела";
$MESS["MAX_TAGS"] = "Максимальное количество тегов";
$MESS["SORT_FIELD"] = "Поле для сортировки";
$MESS["SORT_FIELD_COUNTER"] = "Количество товаров";
$MESS["SORT_FIELD_NAME"] = "Название";
$MESS["SORT_TYPE"] = "Сортировать по:";
$MESS["SORT_TYPE_ASC"] = "Возрастанию";
$MESS["SORT_TYPE_DESC"] = "Убыванию";
$MESS["MAX_VISIBLE_TAGS_DESKTOP"] = "Количество тегов для отображения на десктопах";
$MESS["MAX_VISIBLE_TAGS_MOBILE"] = "Количество тегов для отображения на мобильных";
$MESS["HIDE_TAGS_ON_MOBILE"] = "Скрывать полностью теги на мобильных устройствах";
$MESS["MAIN_SECTION_GROUP"] = "Параметры основного раздела";
$MESS["USE_IBLOCK_MAIN_SECTION"] = "Выводить теги только к основному разделу (если товар привязан к нескольким разделам)";
$MESS["USE_IBLOCK_MAIN_SECTION_TREE"] = "Выводить теги по всему дереву основного раздела";
?>