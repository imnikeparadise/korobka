<?
	$MESS["CATALOG_TAGS_MORE_BUTTON"] = "Показать все";
	$MESS["CATALOG_TAGS_MORE_BUTTON_HIDE"] = "Скрыть";
?>