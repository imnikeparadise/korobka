<?
$MESS["IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип Инфоблока";
$MESS["PICTURE"] = "Изображения";
$MESS["PICTURE_WIDTH"] = "Ширина изображений";
$MESS["PICTURE_HEIGHT"] = "Высота изображений";
$MESS["OFFERS_PROP"] = "Свойство для фильтрации";
$MESS["PRICES_PARAMS"] = "Цены";
$MESS["FILTER"] = "Фильтрация";
$MESS["ELEMENTS_COUNT"] = "Количество элементов";
$MESS["SORT"] = "Сортировка";
$MESS["SORT_PROPERTY_NAME"] = "Поле для сортировки";
$MESS["SORT_VALUE"] = "Тип сортировки";
$MESS["ASC"] = "Во возрастанию";
$MESS["DESC"] = "По убыванию";
$MESS["HIDE_NOT_AVAILABLE"] = "Не отображать товары, которых нет на складах";
$MESS["HIDE_MEASURES"] = "Не отображать единицы измерения у товаров";
$MESS["IBLOCK_PRICE_CODE"] = "Тип цены";
$MESS["CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["CURRENCY_ID"] = "Валюта";
$MESS["LAZY_LOAD_PICTURES"] = "Использовать lazy load для изображений";
?>