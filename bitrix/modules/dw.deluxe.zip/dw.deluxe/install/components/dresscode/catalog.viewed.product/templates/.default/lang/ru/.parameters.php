<?
	$MESS["APAPTIVE_VERSION"] = "Расчитывать адаптив карусели для";
	$MESS["APAPTIVE_VERSION_V1"] = "Шаблона с левым меню";
	$MESS["APAPTIVE_VERSION_V2"] = "Шаблона с верхним меню";
?>