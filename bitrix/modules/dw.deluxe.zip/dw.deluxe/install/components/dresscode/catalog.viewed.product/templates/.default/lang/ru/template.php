<?
	$MESS["SBB_TITLE"] = "Оформление заказа";
	$MESS["VIEW_HEADER"] = "Просмотренные товары";
	$MESS["PRODUCT_BUY"] = "Купить";
	$MESS["PRODUCT_BASKET"] = "В корзину";
	$MESS["FAST_VIEW_PRODUCT_LABEL"] = "Быстрый просмотр";
	$MESS["REQUEST_PRICE_LABEL"] = "Цена по запросу";
	$MESS["REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
?>