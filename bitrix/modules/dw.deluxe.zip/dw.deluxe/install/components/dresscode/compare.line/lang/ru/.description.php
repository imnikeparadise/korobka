<?
$MESS ['NAME'] = "Строка сравнения (DW24)";
$MESS ['DESCRIPTION'] = "Строка сравнения";
?>