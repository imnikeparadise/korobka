<?
	$MESS["COMPARE_HEADING"] = "Сравнение";
	$MESS["COMPARE_EMPTY"] = "Нет товаров";
	$MESS["COMPARE_COUNT"] = "Товаров ";
?>