<?
	$MESS["COMPARE_HEADING"] = "Сравнение";
?>