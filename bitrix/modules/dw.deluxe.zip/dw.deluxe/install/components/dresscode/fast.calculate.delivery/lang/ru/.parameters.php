<?
	$MESS["SITE_ID"] = "ID сайта";
?>