<?
	$MESS["DELIVERY_CITY_LABEL"] = "Стоимость доставки ";
	$MESS["DELIVERY_CITY_IN_LABEL"] = "в";
	$MESS["DELIVERY_QUANTITY_LABEL"] = "Кол-во:";
	$MESS["DELIVERY_ALL_CART_PRODUCTS"] = "Учитывать другие товары в корзине";
?>