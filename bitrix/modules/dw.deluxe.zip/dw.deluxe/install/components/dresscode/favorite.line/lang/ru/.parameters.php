<?
$MESS ['IBLOCK_ID'] = "Инфоблок";
$MESS ['IBLOCK_TYPE'] = "Тип инфоблока";
?>