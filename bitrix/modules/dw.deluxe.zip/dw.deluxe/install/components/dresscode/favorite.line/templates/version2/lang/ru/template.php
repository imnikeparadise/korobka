<?
	$MESS["FAVORITE_HEADING"] = "Избранное";
	$MESS["FAVORITE_EMPTY"] = "Нет товаров";
	$MESS["FAVORITE_COUNT"] = "Товаров ";
?>