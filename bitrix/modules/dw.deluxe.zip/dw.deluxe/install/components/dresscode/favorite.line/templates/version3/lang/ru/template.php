<?
	$MESS["FAVORITE_HEADING"] = "Избранное";
?>