<?
$MESS["IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип Инфоблока";
?> 