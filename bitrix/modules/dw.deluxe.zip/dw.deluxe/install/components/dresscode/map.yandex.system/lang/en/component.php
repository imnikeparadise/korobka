<?
$MESS ['MYMS_ERROR_NO_KEY'] = 'The access key is not specified.';
?>