<?
$MESS ['MYS_LOADING'] = "loading map...";
$MESS ['MYS_LOADING_WAIT'] = "Please wait while the map is being initialized...";
?>