<?
	$MESS["PERSONAL_ERROR"] = "Ошибка";
	$MESS["PERSONAL_SUCCESS_SAVED"] = "Информация успешно сохранена";
	$MESS["PERSONAL_NEED_AUTH"] = "Требуется авторизация";
	$MESS["PERSONAL_SEND_ERROR"] = "Ошибка передачи формы";
	$MESS["PERSONAL_SAVED"] = "Сохранено";
?>