<?
	$MESS["HEADING"] = "Персональные данные";
	$MESS["CHANGE_PASS"] = "Изменить пароль";
	$MESS["PASS"] = "Введите новый пароль";
	$MESS["REPASS"] = "Подтверждение пароля";
	$MESS["SAVE"] = "Сохранить изменения";
	$MESS["SETTINGS"] = "Настройка профиля";
	$MESS["CART"] = "Корзина";
	$MESS["COMPARE"] = "Товары в сравнении";
	$MESS["HISTORY"] = "История заказов";
	$MESS["CALLBACK"] = "Обратная связь";
	$MESS["ERROR"] = "Ошибка";
	$MESS["CLOSE"] = "Закрыть окно";
?>