<?
	$MESS["POP_SECTION_HEADING"] = "Популярные категории товаров";
	$MESS["POP_SECTION_SHOW_MORE"] = "Показать ещё";
	$MESS["POP_SECTION_SHOWS"] = "Показано";
	$MESS["POP_SECTION_FROM"] = "из";
?>