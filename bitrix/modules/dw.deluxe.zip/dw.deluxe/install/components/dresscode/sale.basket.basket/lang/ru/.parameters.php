<?
$MESS["IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["BASKET_PICTURE"] = "Изображения в корзине";
$MESS["BASKET_PICTURE_WIDTH"] = "Ширина изображений";
$MESS["BASKET_PICTURE_HEIGHT"] = "Высота изображений";
$MESS["HIDE_MEASURES"] = "Не отображать единицы измерения у товаров";
$MESS["IBLOCK_PRICE_CODE_GIFT"] = "Типы цен для вывода подарков";
$MESS["PRICES_PARAMS"] = "Цены";
$MESS["GIFT_PARAMS"] = "Подарки";
$MESS["GIFT_CURRENCY_ID"] = "Валюта";
$MESS["GIFT_CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["HIDE_NOT_AVAILABLE"] = "Скрывать недоступные товары";
$MESS["LABELS"] = "Языковые фразы";
$MESS["PART_STORES_AVAILABLE"] = "Если часть товаров в наличии (обозначения в выборе склада)";
$MESS["ALL_STORES_AVAILABLE"] = "Если все товары в наличии (обозначения в выборе склада)";
$MESS["NO_STORES_AVAILABLE"] = "Если товаров нет в наличии (обозначения в выборе склада)";
$MESS["PAYMENT"] = "Платежные системы";
$MESS["PATH_TO_PAYMENT"] = "Страница подключения платежной системы";
$MESS["MIN_SUM_TO_PAYMENT"] = "Минимальная сумма заказа";
$MESS["REGISTER_USER"] = "Оформлять заказ с автоматической регистрацией пользователя?";
$MESS["LAZY_LOAD_PICTURES"] = "Использовать lazy load для изображений";
$MESS["USE_MASKED"] = "Использовать маски для телефонов";
$MESS["MASKED_FORMAT"] = "Формат маски для телефонов";
$MESS["DISABLE_FAST_ORDER"] = "Отключить быстрый заказ";
?>