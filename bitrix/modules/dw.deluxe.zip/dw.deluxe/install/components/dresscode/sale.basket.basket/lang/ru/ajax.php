<?
	$MESS["C3_ORDER_MAKE_ERROR"] = "Заказ не оформлен!";
	$MESS["C3_BASKET_COMPILATION_ERROR"] = "Ошибка компиляции данных!";
	$MESS["C3_BASKET_UPDATE_ERROR"] = "Ошибка обновления товара!";
	$MESS["C3_BASKET_DELETE_ERROR"] = "Ошибка удаления товара!";
	$MESS["C3_BASKET_COUPON_ERROR"] = "Введен неверный купон!";
	$MESS["C3_BASKET_CLEAR_ERROR"] = "Ошибка очистки корзины!";
?>