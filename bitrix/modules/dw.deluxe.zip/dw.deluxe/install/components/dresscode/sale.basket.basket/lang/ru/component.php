<?
	$MESS["PART_STORES_AVAILABLE"] = "Часть позиций отсутствует";
	$MESS["ALL_STORES_AVAILABLE"] = "Все в наличии";
	$MESS["NO_STORES_AVAILABLE"] = "Нет в наличии";
?>