<?
	$MESS["NEW_REGISTER"] = "Приветствуем Вас как нового пользователя нашего сайта!";
	$MESS["CLEAR_CART"]      = "Очистить корзину";
	$MESS["TOP_IMAGE"]       = "Изображение";
	$MESS["TOP_NAME"]        = "Наименование";
	$MESS["TOP_QTY"]         = "Количество";
	$MESS["TOP_AVAILABLE"]   = "Наличие";
	$MESS["TOP_PRICE"]       = "Стоимость";
	$MESS["TOP_SUM"]         = "Сумма";
	$MESS["TOP_DELETE"]      = "Удалить";
	$MESS["AVAILABLE"]       = "в наличии";
	$MESS["NOAVAILABLE"]     = "под заказ";
	$MESS["TOTAL_QTY"]       = "Всего товаров:";
	$MESS["TOTAL_SUM"]       = "Сумма заказа:";
	$MESS["ORDER"]           = "Оформить заказ";
	$MESS["ACCESSORIES"]     = "Рекомендуемые аксессуары";
	$MESS["ADDCART"]         = "В корзину";
	$MESS["EMPTY_HEADING"]   = "В корзине пока пусто";
	$MESS["EMPTY_TEXT"]      = 'Воспользуйтесь поиском или <a href="'.SITE_DIR.'catalog/">каталогом</a>, выберите нужные товары и добавьте их в корзину';
	$MESS["MAIN_PAGE"]       = "Главная страница";
	$MESS["ORDER_EMPTY"]     = "Ваша корзина пуста!";
	$MESS["ORDER_ERROR"]     = "Ошибка оформления заказа";
	$MESS["ORDER_MAKE"]      = 'Ваш заказ № <span id="orderID">1</span> успешно оформлен';
	$MESS["ORDER_MAKE_NEXT"] = 'Вы можете следить за выполнением своего заказа в <a href="'.SITE_DIR.'personal/">Персональном разделе сайта</a>. Обратите внимание, что для входа в этот раздел вам необходимо будет ввести логин и пароль пользователя сайта';
	$MESS["ORDER_HEADING"]   = "Заполните пожалуйста Ваши данные для заказа";
	$MESS["ORDER_PERSON"]    = "Тип плательщика";
	$MESS["ORDER_PERSON_SELECT"] = "Выберите тип плательщика";
	$MESS["ORDER_DELIVERY"]      = "Доставка";
	$MESS["ORDER_PAY"]           = "Оплата";
	$MESS["ORDER_COMMENT"]       = "Комментарий к заказу";
	$MESS["ORDER_GO"]            = "Оформить заказ";
	$MESS["ORDER_ERROR2"]        = "Ошибка";
	$MESS["ORDER_CLOSE"]         = "Закрыть окно";
	$MESS["RUB"]             	 = "руб.";
	$MESS["ADDSKU"]				 = "Уточнить";
	$MESS["FROM"]				 = "от ";

?>