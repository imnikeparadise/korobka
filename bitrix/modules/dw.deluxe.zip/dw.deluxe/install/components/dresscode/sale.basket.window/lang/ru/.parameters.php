<?
	$MESS["BASKET_WINDOW_PRODUCT_ID"] = "ID товара";
	$MESS["BASKET_WINDOW_HIDE_MEASURES"] = "Не отображать единицы измерения у товаров";
	$MESS["BASKET_WINDOW_SITE_ID"] = "ID Сайта";
?>