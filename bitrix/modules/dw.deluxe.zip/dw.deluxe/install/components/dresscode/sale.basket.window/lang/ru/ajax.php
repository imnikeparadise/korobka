<?
	$MESS["C4_BASKET_COMPILATION_ERROR"] = "Ошибка компиляции данных!";
	$MESS["C4_BASKET_UPDATE_ERROR"] = "Ошибка обновления товара!";
	$MESS["C4_BASKET_DELETE_ERROR"] = "Ошибка удаления товара!";
?>