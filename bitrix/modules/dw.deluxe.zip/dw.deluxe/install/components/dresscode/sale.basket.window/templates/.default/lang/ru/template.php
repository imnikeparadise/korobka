<?
	$MESS["BASKET_WINDOW_PRODUCT_ADDED"] = "Товар добавлен в корзину";
	$MESS["BASKET_WINDOW_PRODUCT_QUANTITY"] = "Кол-во:";
	$MESS["BASKET_WINDOW_PRODUCT_TOTAL"] = "Итого:";
	$MESS["BASKET_WINDOW_PRODUCT_CONTINUE"] = "Продолжить покупки";
	$MESS["BASKET_WINDOW_GO_TO_ORDER"] = "Перейти в корзину";
?>