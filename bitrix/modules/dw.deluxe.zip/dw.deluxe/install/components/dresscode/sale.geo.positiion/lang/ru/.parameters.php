<?
	$MESS["PRODUCT_ID_LABEL"] = "ID товара";
	$MESS["GEO_IP_PARAMS"] = "Сервис для определения города";
	$MESS["GEO_IP_PARAMS_YANDEX"] = "Yandex map";
	$MESS["GEO_IP_PARAMS_SYPEXGEO"] = "Sypexgeo.net";
	$MESS["GEO_SYPEX_KEY"] = "Ключ веб-сервиса: sypexgeo";
	$MESS["YANDEX_API_KEY"] = "Yandex api key";
?>