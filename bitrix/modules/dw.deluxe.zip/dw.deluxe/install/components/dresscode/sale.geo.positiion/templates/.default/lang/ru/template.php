<?
	$MESS["SELECT_YOU_GEO_LOCATION"] = "Укажите город";
	$MESS["DETECT_YOU_GEO_LOCATION"] = "Определение";
	$MESS["YOU_GEO_LOCATION_LABEL"] = "Ваш город:";
	$MESS["YOU_GEO_LOCATION_WINDOW_LABEL"] = " Выберите ваш город";
	$MESS["YOU_GEO_LOCATION_BUTTON_LABEL"] = "Запомнить город";
	$MESS["YOU_GEO_LOCATION_CITY_LABEL"] = "Сейчас выбран:";
?>