<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
	$arComponentParameters = array(
		"PARAMETERS" => array(
			"CACHE_TIME" => Array("DEFAULT" => "1285912"),
			"LOCATION_VALUE" => Array(
				"DEFAULT" => "",
				"NAME" => GetMessage("LOCATION_VALUE_LABEL"),
			),
			"SITE_ID"=> Array(
				"DEFAULT" => "",
				"NAME" => GetMessage("SITE_ID_LABEL"),
			),
		)
	);
?>