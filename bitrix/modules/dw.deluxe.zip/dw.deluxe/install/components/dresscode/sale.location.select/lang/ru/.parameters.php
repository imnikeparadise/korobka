<?
	$MESS["LOCATION_VALUE_LABEL"] = "Название местоположения";
	$MESS["SITE_ID_LABEL"] = "Код сайта";
?>

