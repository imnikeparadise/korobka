<?
$MESS ['NAME'] = "Строка поиска (DW24)";
$MESS ['DESCRIPTION'] = "Строка поиска";
?>