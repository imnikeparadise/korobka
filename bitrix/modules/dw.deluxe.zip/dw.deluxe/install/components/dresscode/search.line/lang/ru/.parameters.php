<?
$MESS["IBLOCK_ID"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип Инфоблока";
$MESS["PRICE_CODE"] = "Тип цены";
$MESS["IBLOCK_PRICES"] = "Цены";
$MESS["OFFERS_PROP"] = "Свойство для фильтрации";
$MESS["OFFERS_PROP_VALUE"] = "Значения для фильтрации";
$MESS["FILTER"] = "Фильтрация";
$MESS["IBLOCK_PROPERTY"] = "Свойства";
$MESS["CP_BCS_CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["CP_BCS_CURRENCY_ID"] = "Валюта, в которую будут сконвертированы цены";
$MESS["HIDE_NOT_AVAILABLE"] = "Не отображать товары, которых нет на складах";
$MESS["HIDE_MEASURES"] = "Не отображать единицы измерения у товаров";
$MESS["CONVERT_CASE"] = "Включить автоматическое определение раскладки";
$MESS["LAZY_LOAD_PICTURES"] = "Использовать lazy load для изображений";
$MESS["STEMMING"] = "Использовать морфологию";
?>