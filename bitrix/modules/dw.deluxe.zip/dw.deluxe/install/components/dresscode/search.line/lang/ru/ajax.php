<?
	$MESS["SEARCH_TEXT"] = "Введите текст для поиска";
	$MESS["SEARCH_HEADING"] = "Результаты поиска";
	$MESS["SEARCH_ALL_RESULT"] = "Смотреть все результаты";
	$MESS["SEARCH_ERROR_FOR_EMPTY_RESULT"] = "По вашему поисковому запросу ничего не найдено";
	$MESS["SEARCH_CLOSE_BUTTON"] = "Закрыть окно";
?>