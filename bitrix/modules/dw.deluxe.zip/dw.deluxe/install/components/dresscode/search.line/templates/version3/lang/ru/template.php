<?
	$MESS["SEARCH_TEXT"] = "Поиск по каталогу магазина";
	$MESS["SEARCH_HEADING"] = "Результаты поиска";
	$MESS["SEARCH_ALL_RESULT"] = "Смотреть все результаты";
	$MESS["SEARCH_ERROR_FOR_EMPTY_RESULT"] = "По вашему поисковому запросу ничего не найдено";
	$MESS["SEARCH_CLOSE_BUTTON"] = "Закрыть окно";
?>