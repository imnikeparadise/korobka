<?
$MESS["CP_BCT_TPL_THEME_SITE"] = "Брати тему з налаштувань сайту (для вирішення bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "синя (тема за замовчуванням)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "зелена";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "жовта";
$MESS["CP_BCT_TPL_THEME_RED"] = "червона";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Колірна тема";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "темна";
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Вид відображення";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "Горизонтальний";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "Вертикальний";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Позиція для відображення спливаючого блоку з інформацією про фільтрації";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "зліва";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "праворуч";
?>