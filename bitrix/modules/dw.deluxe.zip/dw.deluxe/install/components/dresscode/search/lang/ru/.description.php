<?
$MESS ['NAME'] = "Страница поиска (DW24)";
$MESS ['DESCRIPTION'] = "Страница поиска";
?>