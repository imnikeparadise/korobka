<?
	$MESS["SEARCH_RESULT"] = "Результаты поиска";
	$MESS["SEARCH_PAGE"] = "Страница поиска";
?>