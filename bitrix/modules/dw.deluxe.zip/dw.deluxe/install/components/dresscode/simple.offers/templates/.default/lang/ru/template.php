<?
	$MESS["CATALOG_SORT_LABEL"] = "Сортировать по:";
	$MESS["CATALOG_SORT_TO_LABEL"] = "Показать по:";	
	$MESS["CATALOG_SORT_FIELD_NAME"] = "алфавиту";
	$MESS["CATALOG_SORT_FIELD_SHOWS"] = "популярности";
	$MESS["CATALOG_SORT_FIELD_PRICE_ASC"] = "увеличению цены";
	$MESS["CATALOG_SORT_FIELD_PRICE_DESC"] = "уменьшению цены";
	$MESS["CATALOG_VIEW_LABEL"] = "Вид каталога:";
	$MESS["SELECT_CATEGORY"] = "Уточните категорию:";
	$MESS["CATALOG_FILTER"] = "Фильтр";
?>