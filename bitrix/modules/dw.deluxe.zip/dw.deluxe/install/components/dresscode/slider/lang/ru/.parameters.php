<?
$MESS["IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["PICTURE"] = "Изображение";
$MESS["PICTURE_WIDTH"] = "Ширина изображений";
$MESS["PICTURE_HEIGHT"] = "Высота изображений";
$MESS["LAZY_LOAD_PICTURES"] = "Использовать lazy load для изображений";
?>