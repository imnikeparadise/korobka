<?$APPLICATION->AddHeadScript(SITE_TEMPLATE_PATH."/js/dwSlider.js");?>
<?$APPLICATION->AddHeadScript($templateFolder."/js/init.js");?>