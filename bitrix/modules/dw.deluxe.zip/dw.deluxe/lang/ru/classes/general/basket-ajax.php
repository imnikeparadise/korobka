<?
	$MESS["C2_BASKET_EMPTY_ERROR"] = "Ваша корзина пуста, возможно заказ уже был оформлен в другом окне!";
	$MESS["C2_BASKET_DATA_EMPTY_ERROR"] = "Данные не отправлены!";
?>