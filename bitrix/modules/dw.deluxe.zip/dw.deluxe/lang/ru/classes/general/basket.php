<?
	$MESS["C1_NEW_USER_REGISTRATION_MESSAGE"] = "Приветствуем Вас как нового пользователя нашего сайта!";
	$MESS["C1_NEW_USER_REGISTRATION_LOGIN_ERROR"] = "Данный адрес электронной почты уже занят.";
	$MESS["C1_NEW_USER_REGISTRATION_LOGIN_PARSE_ERROR"] = "Ошибка получения логина из email.";
	$MESS["C1_NEW_USER_REGISTRATION_PHONE_EMPTY_ERROR"] = "Ошибка, Номер телефона не заполнен.";
?>