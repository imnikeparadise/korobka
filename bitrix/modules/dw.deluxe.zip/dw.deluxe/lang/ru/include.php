<?
$MESS["SCOM_BUTTON_NAME"] = "Мастер#BR#настройки";
$MESS["SCOM_BUTTON_DESCRIPTION"] = "Запустить мастер смены дизайна и настроек сайта";
$MESS["STOM_BUTTON_TITLE_W1"] = "Запустить мастер смены дизайна и настройки магазина";
$MESS["STOM_BUTTON_NAME_W1"] = "<b>Мастер настройки магазина</b>";
$MESS["STOM_BUTTON_TITLE_W5"] = "Запустить мастер создания мобильной версии магазина";
$MESS["STOM_BUTTON_NAME_W5"] = "Мастер создания мобильного магазина";
$MESS["STOM_BUTTON_TITLE_W3"] = "Удаление демонстрационного каталога";
$MESS["STOM_BUTTON_NAME_W3"] = "Удалить демо-каталог";
$MESS["STOM_BUTTON_CONFIRM_W2"] = "Удалить демо-каталог?";
?>