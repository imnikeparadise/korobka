<?
$MESS["SCOM_INSTALL_NAME"] = "Интернет-магазин (DELUXE)";
$MESS["SCOM_INSTALL_DESCRIPTION"] = "Мастер создания интернет-магазина";
$MESS["SCOM_INSTALL_TITLE"] = "Установка модуля";
$MESS["SCOM_UNINSTALL_TITLE"] = "Удаление модуля";
$MESS["SPER_PARTNER"] = "Digital Web";
$MESS["PARTNER_URI"] = "http://dw24.su/";
?>