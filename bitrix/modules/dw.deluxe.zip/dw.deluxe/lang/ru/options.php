<?
	$MESS["ELECTRO_MAIN_HEADING"] = "Настройка параметров модуля";
	$MESS["ELECTRO_TABS_SETTINGS"] = "Основные настройки";

	$MESS["PRODUCT_NAME"] = "Каталог товаров";
	$MESS["PRODUCT_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с товарами:";
	$MESS["PRODUCT_SELECT_IBLOCK_ID"] = "Выберите инфоблок с товарами:";

	$MESS["NEWS_NAME"] = "Новости";
	$MESS["NEWS_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с новостями:";
	$MESS["NEWS_SELECT_IBLOCK_ID"] = "Выберите инфоблок с новостями:";

	$MESS["STOCK_NAME"] = "Акции";
	$MESS["STOCK_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с акциями:";
	$MESS["STOCK_SELECT_IBLOCK_ID"] = "Выберите инфоблок с акциями:";

	$MESS["SURVEY_NAME"] = "Обзоры";
	$MESS["SURVEY_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с обзорами:";
	$MESS["SURVEY_SELECT_IBLOCK_ID"] = "Выберите инфоблок с обзорами:";

	$MESS["BRAND_NAME"] = "Бренды";
	$MESS["BRAND_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с брендами:";
	$MESS["BRAND_SELECT_IBLOCK_ID"] = "Выберите инфоблок с брендами:";

	$MESS["SLIDER_NAME"] = "Слайдер";
	$MESS["SLIDER_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с слайдер:";
	$MESS["SLIDER_SELECT_IBLOCK_ID"] = "Выберите инфоблок с слайдер:";

	$MESS["REVIEW_NAME"] = "Отзывы";
	$MESS["REVIEW_SELECT_IBLOCK_TYPE"] = "Выберите тип инфоблока с отзывами:";
	$MESS["REVIEW_SELECT_IBLOCK_ID"] = "Выберите инфоблок с отзывами:";

	$MESS["CAROUSEL_NAME"] = "Карусель";
	$MESS["CAROUSEL_PROPERTY"] = "Свойство для фильтрации:";
	$MESS["FORM_SUBMIT"] = "Сохранить";

?>