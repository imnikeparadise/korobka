<?
$MESS["CVP_TPL_MESS_RCM"] = "Персональные рекомендации";
$MESS["FAST_VIEW_PRODUCT_LABEL"] = "Быстрый просмотр";
$MESS["REQUEST_PRICE_LABEL"] = "Цена по запросу";
$MESS["REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
?>