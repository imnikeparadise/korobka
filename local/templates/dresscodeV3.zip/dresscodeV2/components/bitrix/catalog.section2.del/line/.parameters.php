<?
	$arTemplateParameters["HIDE_MEASURES"] = array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("HIDE_MEASURES"),
		"TYPE" => "CHECKBOX",
		"REFRESH" => "Y"
	);
?>