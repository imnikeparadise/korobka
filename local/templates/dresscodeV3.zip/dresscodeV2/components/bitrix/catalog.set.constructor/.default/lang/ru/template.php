<?
	$MESS["SNT_HEADING"] = "Купить набор";
	$MESS["SNT_ADDCART"] = "В корзину";
	$MESS["SNT_PRICE"]   = "Стоимость набора:";
	$MESS["SNT_ADDCART_BIG"] = "В корзину";
	$MESS["SNT_ADDSET_BIG"] = "Собрать свой набор ";
	$MESS["SNT_FOR_SET"] = "Составьте свой набор для";
	$MESS["SNT_SUM_PRICE"] = "Стоимость набора:";
	$MESS["SNT_ADDCART_WINDOW"] = "Добавить в корзину";
	$MESS["SNT_CONT"] = "Продолжить покупки";
?>