<?
$MESS['MYMS_TPL_SEARCH'] = "Search Address";
$MESS['MYMS_TPL_SUBMIT'] = "Search";
$MESS['MYMS_TPL_JS_ERROR'] = "Error";
$MESS['MYMS_TPL_JS_SEARCH'] = "Search Results";
$MESS['MYMS_TPL_JS_RESULTS'] = "found";
$MESS['MYMS_TPL_JS_RESULTS_EMPTY'] = "Your search did not match any locations.";
?>