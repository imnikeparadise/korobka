<?
$MESS ['SALE_RECORDS_LIST'] = "List of orders";
$MESS ['SALE_CANCEL_ORDER1'] = "Are you sure you want to cancel";
$MESS ['SALE_CANCEL_ORDER2'] = "the order";
$MESS ['SALE_CANCEL_ORDER3'] = "You cannot restore the order after it is canceled.";
$MESS ['SALE_CANCEL_ORDER4'] = "Please tell us the reason for cancelling the order";
$MESS ['SALE_CANCEL_ORDER_BTN'] = "Cancel the order";
?>