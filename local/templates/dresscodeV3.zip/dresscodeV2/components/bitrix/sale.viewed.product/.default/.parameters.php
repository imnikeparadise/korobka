<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTemplateParameters = array(
	"VIEWED_IMG_HEIGHT" => array(
		"NAME" => GetMessage("VIEWED_IMG_HEIGHT"),
		"TYPE" => "STRING",
		"MULTIPLE" => "N",
		"DEFAULT" => "150",
		"COLS" => 5,
		"PARENT" => "BASE",
	),
	"VIEWED_IMG_WIDTH" => array(
		"NAME" => GetMessage("VIEWED_IMG_WIDTH"),
		"TYPE" => "STRING",
		"MULTIPLE" => "N",
		"DEFAULT" => "150",
		"COLS" => 5,
		"PARENT" => "BASE",
	)
);
?>