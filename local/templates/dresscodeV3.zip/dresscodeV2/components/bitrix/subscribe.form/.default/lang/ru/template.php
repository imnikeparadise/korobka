<?
$MESS ['subscr_form_email_title'] = "Адрес электронной почты";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['SUBSCRIBE_HEADING'] = "Подписка на новости магазина";
?>