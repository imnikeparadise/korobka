<?
$MESS ['subscr_form_email_title'] = "Адрес электронной почты";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['MAIN_SUBSCRIBE_HEADING'] = "Подпишитесь на наши новости";

?>