<?
$MESS ['nav_of'] = "из";
$MESS ['nav_begin'] = "Начало";
$MESS ['nav_prev'] = "Пред.";
$MESS ['nav_next'] = "След.";
$MESS ['nav_end'] = "Конец";
$MESS ['nav_paged'] = "По стр.";
$MESS ['nav_all'] = "Все";
$MESS ['nav_to'] = "-";
?>