<?
$MESS["nav_prev"]="предыдущая";
$MESS["nav_paged"]="По стр.";
$MESS["pages"]="Страницы:";
$MESS["nav_next"]="следующая";
$MESS["nav_all"]="Все";
?>