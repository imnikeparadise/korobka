<?
$MESS["navigation_records_of"] = "of";
$MESS["navigation_pages"] = "Pages:";
$MESS["navigation_all"] = "All";
$MESS["navigation_paged"] = "Paged";
?>