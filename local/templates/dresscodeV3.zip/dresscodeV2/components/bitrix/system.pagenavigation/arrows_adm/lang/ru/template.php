<?
$MESS["navigation_records_of"] = "из";
$MESS["navigation_pages"] = "Страницы:";
$MESS["navigation_all"] = "Все";
$MESS["navigation_paged"] = "По стр.";
?>