<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die(); 

$arTemplateParameters = array(
	"HANDLER" => array(
		"NAME" => GetMessage('MSP_JS_HANDLER'),
		"TYPE" => "STRING",
		"DEFAULT" => '',
	) 
);
?>