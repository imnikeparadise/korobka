<?
$MESS["MSP_JS_HANDLER"] = "Handler";
?>