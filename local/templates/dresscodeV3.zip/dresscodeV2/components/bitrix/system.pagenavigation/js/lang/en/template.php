<?
$MESS["pages"] = "Pages:";
?>