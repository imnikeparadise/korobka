<?
$MESS['MSP_JS_HANDLER'] = 'Обработчик';
?>