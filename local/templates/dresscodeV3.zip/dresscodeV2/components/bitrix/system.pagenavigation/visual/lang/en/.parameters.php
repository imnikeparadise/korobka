<?
$MESS["CP_SPN_TPL_USE_PAGE_SIZE"] = "User can select page size";
$MESS["CP_SPN_TPL_PAGE_SIZE_FROM_LINE_COUNT"] = "Page size is a multiple of table row item count";
$MESS["CP_SPN_TPL_PAGE_SIZES"] = "Page size";
$MESS["CP_SPN_TPL_LINE_COUNT"] = "Items per row";
$MESS["CP_SPN_TPL_MIN_RATIO_LINE_COUNT"] = "Minimum item rows per page";
$MESS["CP_SPN_TPL_MAX_RATIO_LINE_COUNT"] = "Maximum item rows per page";
$MESS["USE_PAGE_SIZE_TIP"] = "User can change the number of items per page";
$MESS["PAGE_SIZE_FROM_LINE_COUNT_TIP"] = "If checked, page size is a multiple of table row item count";
$MESS["PAGE_SIZES_TIP"] = "Standard page sizes. Separate multiple values with a comma.";
$MESS["LINE_COUNT_TIP"] = "Number of items per row is used to estimate page size";
$MESS["MIN_RATIO_LINE_COUNT_TIP"] = "This value specifies minimum possible items per page. If the number of items per row is 1, this value cannot be less than 3.";
$MESS["MAX_RATIO_LINE_COUNT_TIP"] = "This value specifies maximum possible items per page.";
?>