<?
$MESS["nav_of"] = "of";
$MESS["nav_pages"] = "Pages:";
$MESS["nav_all"] = "All";
$MESS["nav_prev_title"] = "Previous page";
$MESS["nav_next_title"] = "Next page";
$MESS["nav_page_num_title"] = "Page #NUM#";
$MESS["nav_page_current_title"] = "Current page";
$MESS["nav_show_pages"] = "Pages";
$MESS["nav_size_descr"] = "Items per page:";
$MESS["nav_all_descr"] = "All entries";
?>