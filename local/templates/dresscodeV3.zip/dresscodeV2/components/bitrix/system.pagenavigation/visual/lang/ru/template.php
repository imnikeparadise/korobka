<?
$MESS["nav_size_descr"] = "По:";
$MESS["nav_of"] = "из";
$MESS["nav_pages"] = "Страницы:";
$MESS["nav_all"] = "Все";
$MESS["nav_prev_title"] = "Предыдущая страница";
$MESS["nav_next_title"] = "Следующая страница";
$MESS["nav_page_num_title"] = "Страница #NUM#";
$MESS["nav_page_current_title"] = "Текущая страница";
$MESS["nav_all_descr"] = "Весь список";
$MESS["nav_show_pages"] = "По стр.";
?>