$(function() {

	$("#middleSlider").dwSlider({
		delay: 4000,
		speed: 800,
        rightButton: ".middleSliderBtnRight",
        leftButton: ".middleSliderBtnLeft"
	});

});