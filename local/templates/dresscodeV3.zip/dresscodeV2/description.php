<?
$arTemplate = array (
  'NAME' => 'Optogram v1',
  'DESCRIPTION' => 'Optogram v1',
  'SORT' => 1,
  'TYPE' => '',
);
?>