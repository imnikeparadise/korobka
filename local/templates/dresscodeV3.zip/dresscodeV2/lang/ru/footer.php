<?
	$MESS["BASKET_ADDED"] = "В корзине";
	$MESS["DRESS_CATALOG"] = "Каталог товаров";
	$MESS["ADD_COMPARE_ADDED"] = "Добавлено";
	$MESS["WISHLIST_ADDED"] = "Добавлено";
	$MESS["ADD_CART_LOADING"] = "Загрузка";
	$MESS["ADDED_CART_SMALL"] = "В корзине";
	$MESS["FOOTER_CALLBACK_LABEL"] = "Обратная связь";
	$MESS["ADD_BASKET_DEFAULT_LABEL"] = "В корзину";
	$MESS["CATALOG_AVAILABLE"] = "В наличии";
	$MESS["CATALOG_ON_ORDER"] = "Под заказ";
	$MESS["CATALOG_NO_AVAILABLE"] = "Недоступно";
	$MESS["COLOR_SWITCHER"] = "Цветовая схема:";
	$MESS["COLOR_SWITCHER_CLOSE"] = "Закрыть";
	$MESS["BACKGROUND_SWITCHER"] = "Цвет фона";
	$MESS["FAST_VIEW_PRODUCT_LABEL"] = "Быстрый просмотр";
	$MESS["REQUEST_PRICE_LABEL"] = "Цена по запросу";
	$MESS["REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
	$MESS["TOP_MENU_HEADING"] = "Верхнее меню";
	$MESS["LEFT_MENU_HEADING"] = "Левое меню";
	$MESS["COLOR_SWITCHER_MENU"] = "Тип шаблона";
	$MESS["SECT_FOOTER_COUNTERS"] = "счетчики";
	$MESS["GIFT_PRICE_LABEL"] = "Бесплатно";
	$MESS["CATALOG_ECONOMY"] = "Экономия: ";
	$MESS["WISHLIST_SENDED"] = "Отправлено";
	$MESS["ADD_SUBSCRIBE_LABEL"] = "Подписаться";
	$MESS["REMOVE_SUBSCRIBE_LABEL"] = "Отписаться";
?>