<?
	$MESS["DRESS_CATALOG"] = "Каталог товаров";
	$MESS["SECT_SUBSCRIBE"] = " | Текст около подписки";
	$MESS["SECT_LEFT_BANNER_1"] = " | Путь до изображения 1 банера";
	$MESS["SECT_LEFT_BANNER_1"] = " | Путь до изображения 2 банера";
	$MESS["BASKET_ADDED"] = "В корзине";
?>